﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data.Common;
using System.Drawing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections.ObjectModel;

namespace BDSistemaVentas
{
    class csConexion
    {
        SqlConnection conexion;
        SqlCommand cCOM;
        SqlDataAdapter cDA;
        SqlDataReader cDR;
        DataSet cDS;
        DataTable cDT;
        string server;
        string baseDatos;
        string Cadena;
        public string Server
        {
            get { return server; }
            set { server = value; }
        }
        public string BaseDatos
        {
            get { return baseDatos; }
            set { baseDatos = value; }
        }

        public csConexion()
        {
            Server = "JEREMY\\SQLEXPRESS";
            BaseDatos = "ASU1";
        }
        public csConexion(string ser, string bd)
        {
            Server = ser;
            BaseDatos = bd;
        }
        public bool abrirConexion()
        {
            try
            {
                conexion = new SqlConnection();
                conexion.ConnectionString = "Server=" + Server + "; Database=" + BaseDatos + ";integrated security=true";
                conexion.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de apertura");
                return false;
            }
            
            return true;
        }
        public bool cerrarConexion()
        {
            try
            {
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de cerrado");
                return false;
            }

            return true;
        }

        public SqlCommand confirmar(string sentencia)
        {
            try
            {
                if (sentencia.Length > 0)
                {
                    cCOM = new SqlCommand(sentencia, conexion);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error");
            }
            
            return cCOM;
        }
        public DataSet retornarregristros(string sentencia)
        {
            try
            {
                if (sentencia.Length > 0)
                {
                    abrirConexion();
                    cCOM = new SqlCommand(sentencia, conexion);
                    cDA = new SqlDataAdapter(cCOM);
                    cDS = new DataSet("dsRetorna");
                    cDA.Fill(cDS, "dsRetorna");
                    cerrarConexion();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error en acceso de datos");
            }
            return cDS;
        }

        public DataTable retornarregistro(string Sentencia)
        {
            if (Sentencia.Length > 0)
            {
                abrirConexion();
                cCOM = new SqlCommand(Sentencia, conexion);
                cDA = new SqlDataAdapter(cCOM);
                cDT = new DataTable();
                cDA.Fill(cDT);
                cerrarConexion();
            }
            return cDT;
        }
        
        //codigo unico
        public int GenerarCodigoUnico(string Tabla,string Campo)
        {
            int nextCode = 1;
            abrirConexion();
            Cadena = $"SELECT {Campo} FROM {Tabla} ORDER BY {Campo}";
            cCOM = new SqlCommand(Cadena, conexion);
            using (SqlDataReader reader = cCOM.ExecuteReader())
            {
                while (reader.Read())
                {
                    int codigoconcurrente = reader.GetInt32(0);
                    if (codigoconcurrente != nextCode)
                        break;
                    nextCode++;
                }
            }
            cerrarConexion();
            return nextCode;
        }
        public bool InsertarDatos(string Cadena)
        {
            try
            {
                abrirConexion();
                
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
                //ALTER
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool sumarcantidad(int id, decimal cant)
        {
            try
            {
                abrirConexion();
                SqlCommand cCOM = new SqlCommand("SumarAbono", conexion);
                cCOM.CommandType = CommandType.StoredProcedure;
                cCOM.Parameters.Add(new SqlParameter("@PlazoID", SqlDbType.Int)).Value = id;
                SqlParameter paramCant = new SqlParameter("@NuevoAbono", SqlDbType.Decimal);
                paramCant.Precision = 12;  
                paramCant.Scale = 2;       
                paramCant.Value = cant;
                cCOM.Parameters.Add(paramCant);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        //------------------------------------ENVIO DATOS-------------------------------------

        public bool transaccion(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC CompletarVentaAbonada {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }
        
        //-------------------------------INSERSION DE DATOS----------------------------------

        public bool insertarDatosProveedor(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarProveedor {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosAdmin(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"Exec RegistrarAdministrador {Datos}";
                //Exec RegistrarAdmin 4, 'Petulio', 'Margaro', 'Petulito@gmail.com', '1250270756', '0997957931', 'Santa Rosa', 'Quevedo', 'Ecuador', 'Petulito', 'Margarita.214'
                //insertar = $"INSERT INTO {tabla} ({campos}) VALUES ({datos})";
                //funcion = "SELECT dbo.VtaTotalCliente(@Cliente)";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosCliente(string DatosC)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarCliente {DatosC}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarPromo(string DatosC)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarPromo {DatosC}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosProducto(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarProducto {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosOrdenC(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarOrdenContractual {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosDetalleC(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarDetalleOrden {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosVenta(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarVenta {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosDetalleVenta(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarDetalleVenta {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }
        
        public bool insertarOrdenPlazos(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarPlazo {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool insertarDatosDetallePlazo(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC RegistrarDetallePlazo {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool elininarDatosCliente(int Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC EliminarCliente {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool eliminarDatosVenta(int Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC EliminarVenta {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool eliminarDatosOrden(int Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC EliminarOrden {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool eliminarDatosProveedor(int Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC EliminarProveedor {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool eliminarDatosProducto(int Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"EXEC EliminarProducto {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }
    }
}
