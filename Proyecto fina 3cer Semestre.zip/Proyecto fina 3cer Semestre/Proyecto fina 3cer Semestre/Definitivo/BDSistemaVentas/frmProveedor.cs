﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmProveedor : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public frmProveedor()
        {
            InitializeComponent();
            mostrardatosProveedores();
            CargarProveedores();
        }

        private void btn_InsertarDatosProveedores_Click_1(object sender, EventArgs e)
        {
            frmCrearProveedor crearProveedor = new frmCrearProveedor();
            crearProveedor.Show();
        }

        private void btnNuevoProveedor_Click(object sender, EventArgs e)
        {
            frmCrearProveedor frm = new frmCrearProveedor();
            frm.ShowDialog();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string nombre = csGlobalVariablesProveedor.MiVariableGlobalProveedor;
            if (nombre != "")
            {
                cadena = $"Select * from Proveedor where Nombre = '{nombre}'";
                
                DataSet ds = sqlCon.retornarregristros(cadena);
                dgvProveedores.Rows.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    DataRow fila = ds.Tables[0].Rows[i];
                    object[] valores = new object[fila.ItemArray.Length];

                    for (int j = 0; j < fila.ItemArray.Length; j++)
                    {
                        valores[j] = fila[j];
                    }

                    dgvProveedores.Rows.Add(valores);
                }
            }
            else
            {
                mostrardatosProveedores();
                MessageBox.Show("no hay que buscar");
            }
        }
        private void mostrardatosProveedores()
        {
            cadena = "Select * from Proveedor";
            DataSet ds = sqlCon.retornarregristros(cadena);
            dgvProveedores.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores4 = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores4[j] = fila[j];
                }

                dgvProveedores.Rows.Add(valores4);
            }
        }

        private void btnEliminarProveedores_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgvProveedores.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvProveedores.Rows[selectedRowIndex];
                int proveedorID = Convert.ToInt32(selectedRow.Cells["ProovedorID"].Value);
                sqlCon.eliminarDatosProveedor(proveedorID);
                mostrardatosProveedores();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione un proveedor");
            }
        }

        private void cbProveedores_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProveedorSelec = cbProveedores.SelectedItem.ToString();
            cadena = $"SELECT Nombre FROM Proveedor WHERE Nombre = '{ProveedorSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string proveedor = ds.Tables[0].Rows[0]["Nombre"].ToString().Trim();
                csGlobalVariablesProveedor.MiVariableGlobalProveedor = $"{proveedor}";
            }
        }

        private void CargarProveedores()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Proveedor";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbProveedores.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbProveedores.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }
    }
}
