﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmCrearProveedor : Form
    {
        csConexion sqlCon = new csConexion();
        public frmCrearProveedor()
        {
            InitializeComponent();
        }

        private void btnGuardarProveedor_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "" || txtRuc.Text == "" || txtCiudad.Text == "" || txtDireccion.Text == "" || txtTelefono.Text == "" || txtCorreo.Text == "" || txtPais.Text == "")
            {
                MessageBox.Show("Datos faltantes");
            }
            else if (txtRuc.Text.Length != 10)
            {
                MessageBox.Show("Solo 10 digitos en la cedula");
            }
            else
            {
                int ProveedorID = sqlCon.GenerarCodigoUnico("Proveedor", "ProveedorID");
                string NombreR = txtNombre.Text;
                string Ruc = txtRuc.Text;
                string CiudadR = txtCiudad.Text;
                string Direccion = txtDireccion.Text;
                string telefono = txtTelefono.Text;
                string Correo = txtCorreo.Text;
                string pais = txtPais.Text;
                string valores = $"{ProveedorID},'{NombreR}', '{Ruc}', '{CiudadR}', '{Direccion}', '{telefono}', '{Correo}', '{pais}'";
                sqlCon.insertarDatosProveedor(valores);
            }
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPais_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCiudad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtRuc_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }*/
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void frmCrearProveedor_Load(object sender, EventArgs e)
        {

        }
    }
}
