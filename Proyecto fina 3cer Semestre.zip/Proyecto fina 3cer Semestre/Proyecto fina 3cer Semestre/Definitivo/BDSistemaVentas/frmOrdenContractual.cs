﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;
using System.Drawing.Printing;
using System.Reflection;

namespace BDSistemaVentas
{
    public partial class frmOrdenContractual : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        int ClientexPag = 40;
        int Bandera = 0;
        public frmOrdenContractual()
        {
            InitializeComponent();
            detalleO();
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnNuevaOrden_Click(object sender, EventArgs e)
        {
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
        }

        private void btnDetalle_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void detalleO()
        {
            int OrdenID = csGlobalVariablesOC.MiVariableGlobalOC;
            string cadena = $"select D.OrdenID, P.Nombre, D.Cantidad_Pedida, D.Cantidad_Entregada, D.Precio_Compra from Producto P inner join Detalle_Orden D on P.ProductoID=D.ProductoID where D.OrdenID = {OrdenID}";
            DataSet ds = sqlCon.retornarregristros(cadena);
            dgvProductos.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores[j] = fila[j];
                }

                dgvProductos.Rows.Add(valores);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            try
            {
                prdImprimir = new PrintDocument();
                PrinterSettings ps = new PrinterSettings();
                prdImprimir.PrinterSettings = ps;
                prdImprimir.PrintPage += Imprimir;
                prdImprimir.Print();
                var selectedCell = dgvProductos.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvProductos.Rows[selectedRowIndex];
                string Producto = Convert.ToString(selectedRow.Cells["Producto"].Value);
                string CantidadS = Convert.ToString(selectedRow.Cells["CantidadS"].Value);
                string CantidadE = Convert.ToString(selectedRow.Cells["CantidadE"].Value);
                string PrecioC = Convert.ToString(selectedRow.Cells["PrecioC"].Value);
                csDatosOrden.Producto = Producto;
                csDatosOrden.CantidadS = CantidadS;
                csDatosOrden.CantidadE = CantidadE;
                csDatosOrden.PrecioU = PrecioC;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir: " + ex.Message);
            }

        }

        private void Imprimir(object sender, PrintPageEventArgs e)
        {
            float y = 390;
            int id = csGlobalVariablesOC.MiVariableGlobalOC;
            string fechaS = csDatosOrden.FechaEmision;
            string fechaE = csDatosOrden.FechaEntrega;
            string proveedor = csDatosOrden.NombreProveedor;
            string admin = csDatosOrden.Administrador;
            string producto = csDatosOrden.Producto;
            string cantidadS = csDatosOrden.CantidadS;
            string cantidadE = csDatosOrden.CantidadE;
            string PrecioU = csDatosOrden.PrecioU;
            string ValT = csDatosOrden.PrecioT;
            //e.Graphics.DrawImage(imlImagenes.Images[0], new RectangleF(100, 0, imlImagenes.Images[0].Width / 2, imlImagenes.Images[0].Height / 2));
            Font fuente = new Font("Arial", 20, FontStyle.Bold);
            e.Graphics.DrawString("Wachiturros Center", fuente, Brushes.BlueViolet, new RectangleF(275, 20, 300, 40));
            fuente = new Font("Arial", 12, FontStyle.Bold);
            e.Graphics.DrawString("Factura:", fuente, Brushes.Black, new RectangleF(0, 100, 90, 50));
            e.Graphics.DrawString($"{id}", fuente, Brushes.Black, new RectangleF(160, 100, 130, 50));
            e.Graphics.DrawString("Fecha de emision:", fuente, Brushes.Black, new RectangleF(0, 140, 210, 50));
            e.Graphics.DrawString($"{fechaS}", fuente, Brushes.Black, new RectangleF(160, 140, 130, 50));
            e.Graphics.DrawString("Fecha de entrega:", fuente, Brushes.Black, new RectangleF(0, 180, 210, 50));
            e.Graphics.DrawString($"{fechaE}", fuente, Brushes.Black, new RectangleF(160, 180, 130, 50));
            e.Graphics.DrawString("Proveedor:", fuente, Brushes.Black, new RectangleF(0, 220, 100, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(160, 220, 130, 50));
            /*e.Graphics.DrawString("Ruc:", fuente, Brushes.Black, new RectangleF(220, 220, 90, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(320, 220, 130, 50));
            e.Graphics.DrawString("Direccion Proveedor:", fuente, Brushes.Black, new RectangleF(0, 220, 90, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(110, 220, 130, 50));
            e.Graphics.DrawString("Telefono:", fuente, Brushes.Black, new RectangleF(0, 220, 90, 50));*
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(110, 220, 130, 50));
            e.Graphics.DrawString("Correo Electronico:", fuente, Brushes.Black, new RectangleF(0, 220, 90, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(110, 220, 130, 50));*/
            e.Graphics.DrawString("Encargado:", fuente, Brushes.Black, new RectangleF(420, 220, 120, 50));
            e.Graphics.DrawString($"{admin}", fuente, Brushes.Black, new RectangleF(540, 220, 130, 50));
            /*e.Graphics.DrawString("Telefono:", fuente, Brushes.Black, new RectangleF(0, 220, 90, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(110, 220, 130, 50));
            e.Graphics.DrawString("Correo Electronico:", fuente, Brushes.Black, new RectangleF(0, 220, 90, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(110, 220, 130, 50));*/

            fuente = new Font("Arial", 14, FontStyle.Bold);
            e.Graphics.DrawString("DETALLE", fuente, Brushes.Red, new RectangleF(0, 280, 200, 20));
            fuente = new Font("Arial", 12, FontStyle.Bold);
            e.Graphics.DrawString("Producto.", fuente, Brushes.Black, new RectangleF(30, 340, 180, 20));
            e.Graphics.DrawString("Cantidad Solicitada.", fuente, Brushes.Black, new RectangleF(220, 340, 75, 20));
            e.Graphics.DrawString("Cantidad Entregada.", fuente, Brushes.Black, new RectangleF(305, 340, 300, 20));
            e.Graphics.DrawString("Precio Unitario.", fuente, Brushes.Black, new RectangleF(500, 340, 150, 20));
            //e.Graphics.DrawString("TOTAL:.", fuente, Brushes.Black, new RectangleF(660, 340, 150, 20));
            e.Graphics.DrawLine(new Pen(Color.Black, 1), 0, 380, 800, 380);


            fuente = new Font("Arial", 12, FontStyle.Regular);
            cadena = $"select P.Nombre, D.Cantidad_Pedida, D.Cantidad_Entregada, D.Precio_Compra from Producto P inner join Detalle_Orden D on P.ProductoID=D.ProductoID where D.OrdenID = {id}";
            DataTable dt = sqlCon.retornarregistro(cadena);
            for (int i = 0; Bandera < dt.Rows.Count && i < ClientexPag; i++, Bandera++)
            {
                e.Graphics.DrawString((Bandera + 1).ToString(), fuente, Brushes.Black, new RectangleF(0, y, 40, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Nombre"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(30, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Cantidad_Pedida"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(220, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Cantidad_Entregada"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(305, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Precio_Compra"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(500, y, 75, 20));
                y += 20;
            }
            e.HasMorePages = Bandera < dt.Rows.Count;
            fuente = new Font("Arial", 14, FontStyle.Bold);
            e.Graphics.DrawString("RESUMEN:", fuente, Brushes.Red, new RectangleF(0, y + 30, 200, 20));
            fuente = new Font("Arial", 12, FontStyle.Bold);
            e.Graphics.DrawString("Total a pagar:", fuente, Brushes.Black, new RectangleF(0, y + 80, 180, 20));
            e.Graphics.DrawString($"{ValT}", fuente, Brushes.Black, new RectangleF(110, y + 80, 130, 50));
            
        }
    }
}
