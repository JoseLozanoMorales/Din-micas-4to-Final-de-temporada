﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmOrdenCompra : Form
    {
        string cadena;
        csConexion sqlCon = new csConexion();
        public frmOrdenCompra()
        {
            InitializeComponent();
            mostrardatosCompra();
        }

        private void btn_Insertar_OrdenContractual_Click(object sender, EventArgs e)
        {
            frmInsertarOrdenContractual insertarOrdenContractual = new frmInsertarOrdenContractual();
            insertarOrdenContractual.Show();
        }

        private void btnDetalleOrden_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgbOrdenC.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgbOrdenC.Rows[selectedRowIndex];
                int OrdenID = Convert.ToInt32(selectedRow.Cells["OrdenID"].Value);
                DateTime fechaS = Convert.ToDateTime(selectedRow.Cells["FechaS"].Value);
                DateTime fechaE = Convert.ToDateTime(selectedRow.Cells["FechaE"].Value);
                string Proveedor = Convert.ToString(selectedRow.Cells["Proveedor"].Value);
                string Administrador = Convert.ToString(selectedRow.Cells["AdministradorN"].Value);
                string valorT = Convert.ToString(selectedRow.Cells["Valor_Total"].Value);
                string fecha1 = fechaS.ToString("yyyy-MM-dd");
                string fecha2 = fechaE.ToString("yyyy-MM-dd");
                csGlobalVariablesOC.MiVariableGlobalOC = OrdenID;
                csDatosOrden.FechaEmision = fecha1;
                csDatosOrden.FechaEntrega = fecha2;
                csDatosOrden.NombreProveedor = Proveedor;
                csDatosOrden.Administrador = Administrador;
                csDatosOrden.PrecioT = valorT;
                frmOrdenContractual frm = new frmOrdenContractual();
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione Una Venta");
            }
            
        }

        private void btnEliminarAdmin_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgbOrdenC.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgbOrdenC.Rows[selectedRowIndex];
                int OrdenID = Convert.ToInt32(selectedRow.Cells["OrdenID"].Value);
                sqlCon.eliminarDatosOrden(OrdenID);
                mostrardatosCompra();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione un proveedor");
            }
        }

        private void btnAgregarC_Click(object sender, EventArgs e)
        {
            frmInsertarOrdenContractual frm = new frmInsertarOrdenContractual();
            frm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void mostrardatosCompra()
        {
            cadena = "select O.OrdenID, O.Fecha_Emision, O.Fecha_Entrega, O.Valor_Total, P.Nombre, A.Nombre, A.Apellido from Proveedor P inner join Orden_Contractual O on P.ProveedorID=O.ProveedorID inner join Administrador A on O.AdministradorID=A.AdministradorID";
            DataSet ds = sqlCon.retornarregristros(cadena);
            dgbOrdenC.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores3 = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores3[j] = fila[j];
                }

                dgbOrdenC.Rows.Add(valores3);
            }
        }

        private void dgbOrdenC_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
