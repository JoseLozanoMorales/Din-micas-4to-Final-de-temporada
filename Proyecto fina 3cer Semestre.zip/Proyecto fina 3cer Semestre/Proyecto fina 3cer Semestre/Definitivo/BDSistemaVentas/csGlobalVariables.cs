﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDSistemaVentas
{
    class csGlobalVariables
    {
        public static string MiVariableGlobal;
    }

    class csGlobalVariablesCategoria
    {
        public static string MiVariableGlobalCategoria;
    }
    class csGlobalVariablesProveedor
    {
        public static string MiVariableGlobalProveedor;
    }

    class csGlobalVariablesAdmin
    {
        public static string MiVariableGlobalAdmin;
    }
    class csGlobalVariablesProduct
    {
        public static string MiVariableGlobalProduct;
        public static string stock;
    }
    
    class csGlobalVariablesOrden
    {
        public static int MiVariableGlobalOrden;
    }

    class csGlobalVariablesCliente
    {
        public static string MiVariableGlobalCliente;
    }
    class csGlobalVariablesPrecio
    {
        public static string MiVariableGlobalPrecio;
    }

    class csGlobalVariablesIVA
    {
        public static string MiVariableGlobalIVA;
    }
    class csGlobalVariablesDV
    {
        public static int MiVariableGlobalDV;
    }

    class csGlobalVariablesOC
    {
        public static int MiVariableGlobalOC;
    }

    class csDatosVentas
    {
        public static string Fecha;
        public static string cliente;
        public static string Administrador;
        public static string Subtotal;
        public static string Ventatotal;
    }
    //------------------DATOS PARA FACTURA ORDEN--------------
    class csDatosOrden
    {
        public static string FechaEmision;
        public static string FechaEntrega;
        public static string NombreProveedor;
        public static string Administrador;
        public static string Producto;
        public static string CantidadS;
        public static string CantidadE;
        public static string PrecioU;
        public static string PrecioT;
    }
    class csTipoV
    {
        public static int Tipo_Venta;
    }
    //----------------------PLAZOS-----------------------------
    class csPlazos
    {
        public static int ID;
    }
    //---------------------MONTOS------------------------------
    class csMontos
    {
        public static decimal Inicial;
        public static decimal Final;
        public static int ID;
        public static DateTime FechaI;
    }

    class csCliente
    {
        public static int ID;
    }

    class csPromociones
    {
        public static int Idex;
        public static int descuento;
        public static string Nombre;
        public static string Tipo_Promo;
    }

}
