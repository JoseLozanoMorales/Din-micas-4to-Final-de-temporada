﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BDSistemaVentas
{

    public partial class Inicio : Form
    {
        private void UpdateDateTime(object sender, EventArgs e)
        {
            lbl_Hora.Text = DateTime.Now.ToString("HH:mm:ss");
            lbl_Fecha.Text = DateTime.Now.ToLongDateString();
        }
        public Inicio()
        {
            InitializeComponent();
            Timer timer = new Timer();
            timer.Interval = 1000; // 1 segundo
            timer.Tick += new EventHandler(UpdateDateTime);
            timer.Start();
        }
    }
}
