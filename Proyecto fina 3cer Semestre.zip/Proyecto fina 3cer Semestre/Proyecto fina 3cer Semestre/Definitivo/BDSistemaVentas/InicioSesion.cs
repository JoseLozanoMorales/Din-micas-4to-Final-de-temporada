﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BDSistemaVentas.frmContenedor;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class InicioSesion : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public InicioSesion()
        {
            InitializeComponent();
        }

        private void btnIniciar_Sesion_Click(object sender, EventArgs e)
        {
            string nombre, contrasenia;
            nombre = txtUsuario.Text;
            contrasenia = txtContrasenia.Text;
            sqlCon.abrirConexion();
            cadena = $"SELECT * FROM Administrador WHERE Nombreusuario = '{nombre}' AND CONVERT(VARCHAR, DECRYPTBYPASSPHRASE('password', Contraseña)) = '{contrasenia}'";
            
            SqlCommand comando = sqlCon.confirmar(cadena);
            SqlDataReader lector;
            lector = comando.ExecuteReader();

            if (lector.HasRows == true)
            {
                cadena = $"SELECT * FROM Administrador WHERE Nombreusuario = '{nombre}'";

                DataSet ds = sqlCon.retornarregristros(cadena);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    // Asume que la categoría está en la primera fila y columna
                    string adminID = ds.Tables[0].Rows[0]["AdministradorID"].ToString().Trim();
                    
                }
                frmContenedor frm = new frmContenedor();
                this.Hide();
                frm.Show();
            }
            else
            {
                //MessageBox.Show("usuario o contraseña incorrecta");
                label3.Text = "Credenciales incorrectas";
                label3.ForeColor = Color.Red;
            }
            sqlCon.cerrarConexion();
            
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
