﻿namespace BDSistemaVentas
{
    partial class frmOrdenCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOrdenCompra));
            this.dgbOrdenC = new System.Windows.Forms.DataGridView();
            this.OrdenID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FechaS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FechaE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Valor_Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Proveedor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AdministradorN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDetalleOrden = new System.Windows.Forms.Button();
            this.btnEliminarAdmin = new System.Windows.Forms.Button();
            this.btnAgregarC = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgbOrdenC)).BeginInit();
            this.SuspendLayout();
            // 
            // dgbOrdenC
            // 
            this.dgbOrdenC.AllowUserToAddRows = false;
            this.dgbOrdenC.AllowUserToDeleteRows = false;
            this.dgbOrdenC.AllowUserToResizeColumns = false;
            this.dgbOrdenC.AllowUserToResizeRows = false;
            this.dgbOrdenC.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgbOrdenC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgbOrdenC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbOrdenC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.OrdenID,
            this.FechaS,
            this.FechaE,
            this.Valor_Total,
            this.Proveedor,
            this.AdministradorN,
            this.Column3});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgbOrdenC.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgbOrdenC.Location = new System.Drawing.Point(11, 65);
            this.dgbOrdenC.Margin = new System.Windows.Forms.Padding(2);
            this.dgbOrdenC.Name = "dgbOrdenC";
            this.dgbOrdenC.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgbOrdenC.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgbOrdenC.RowHeadersVisible = false;
            this.dgbOrdenC.RowHeadersWidth = 51;
            this.dgbOrdenC.RowTemplate.Height = 24;
            this.dgbOrdenC.ShowCellErrors = false;
            this.dgbOrdenC.ShowCellToolTips = false;
            this.dgbOrdenC.ShowEditingIcon = false;
            this.dgbOrdenC.ShowRowErrors = false;
            this.dgbOrdenC.Size = new System.Drawing.Size(885, 470);
            this.dgbOrdenC.TabIndex = 55;
            this.dgbOrdenC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbOrdenC_CellContentClick);
            // 
            // OrdenID
            // 
            this.OrdenID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.OrdenID.HeaderText = "OrdenID";
            this.OrdenID.MinimumWidth = 6;
            this.OrdenID.Name = "OrdenID";
            this.OrdenID.ReadOnly = true;
            // 
            // FechaS
            // 
            this.FechaS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FechaS.HeaderText = "Fecha_Emision";
            this.FechaS.MinimumWidth = 6;
            this.FechaS.Name = "FechaS";
            this.FechaS.ReadOnly = true;
            // 
            // FechaE
            // 
            this.FechaE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FechaE.HeaderText = "Fecha_Entrega";
            this.FechaE.MinimumWidth = 6;
            this.FechaE.Name = "FechaE";
            this.FechaE.ReadOnly = true;
            // 
            // Valor_Total
            // 
            this.Valor_Total.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Valor_Total.HeaderText = "Valor Total";
            this.Valor_Total.MinimumWidth = 6;
            this.Valor_Total.Name = "Valor_Total";
            this.Valor_Total.ReadOnly = true;
            // 
            // Proveedor
            // 
            this.Proveedor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Proveedor.HeaderText = "Proveedor";
            this.Proveedor.MinimumWidth = 6;
            this.Proveedor.Name = "Proveedor";
            this.Proveedor.ReadOnly = true;
            // 
            // AdministradorN
            // 
            this.AdministradorN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.AdministradorN.HeaderText = "Administrador(Nombre)";
            this.AdministradorN.MinimumWidth = 6;
            this.AdministradorN.Name = "AdministradorN";
            this.AdministradorN.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Administrador(Apellido)";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // btnDetalleOrden
            // 
            this.btnDetalleOrden.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnDetalleOrden.FlatAppearance.BorderSize = 0;
            this.btnDetalleOrden.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnDetalleOrden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDetalleOrden.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetalleOrden.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDetalleOrden.Image = ((System.Drawing.Image)(resources.GetObject("btnDetalleOrden.Image")));
            this.btnDetalleOrden.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDetalleOrden.Location = new System.Drawing.Point(614, 548);
            this.btnDetalleOrden.Name = "btnDetalleOrden";
            this.btnDetalleOrden.Size = new System.Drawing.Size(145, 40);
            this.btnDetalleOrden.TabIndex = 64;
            this.btnDetalleOrden.Text = "Detalles";
            this.btnDetalleOrden.UseVisualStyleBackColor = false;
            this.btnDetalleOrden.Click += new System.EventHandler(this.btnDetalleOrden_Click);
            // 
            // btnEliminarAdmin
            // 
            this.btnEliminarAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnEliminarAdmin.FlatAppearance.BorderSize = 0;
            this.btnEliminarAdmin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnEliminarAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminarAdmin.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarAdmin.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnEliminarAdmin.Image = ((System.Drawing.Image)(resources.GetObject("btnEliminarAdmin.Image")));
            this.btnEliminarAdmin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminarAdmin.Location = new System.Drawing.Point(463, 548);
            this.btnEliminarAdmin.Name = "btnEliminarAdmin";
            this.btnEliminarAdmin.Size = new System.Drawing.Size(145, 40);
            this.btnEliminarAdmin.TabIndex = 63;
            this.btnEliminarAdmin.Text = "Eliminar";
            this.btnEliminarAdmin.UseVisualStyleBackColor = false;
            this.btnEliminarAdmin.Click += new System.EventHandler(this.btnEliminarAdmin_Click);
            // 
            // btnAgregarC
            // 
            this.btnAgregarC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnAgregarC.FlatAppearance.BorderSize = 0;
            this.btnAgregarC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnAgregarC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarC.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarC.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAgregarC.Image = ((System.Drawing.Image)(resources.GetObject("btnAgregarC.Image")));
            this.btnAgregarC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregarC.Location = new System.Drawing.Point(312, 548);
            this.btnAgregarC.Name = "btnAgregarC";
            this.btnAgregarC.Size = new System.Drawing.Size(145, 40);
            this.btnAgregarC.TabIndex = 68;
            this.btnAgregarC.Text = "Agregar";
            this.btnAgregarC.UseVisualStyleBackColor = false;
            this.btnAgregarC.Click += new System.EventHandler(this.btnAgregarC_Click);
            // 
            // frmOrdenCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(93)))), ((int)(((byte)(90)))));
            this.ClientSize = new System.Drawing.Size(1040, 600);
            this.Controls.Add(this.btnAgregarC);
            this.Controls.Add(this.btnDetalleOrden);
            this.Controls.Add(this.btnEliminarAdmin);
            this.Controls.Add(this.dgbOrdenC);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmOrdenCompra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmOrdenCompra";
            ((System.ComponentModel.ISupportInitialize)(this.dgbOrdenC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dgbOrdenC;
        private System.Windows.Forms.Button btnDetalleOrden;
        private System.Windows.Forms.Button btnEliminarAdmin;
        private System.Windows.Forms.Button btnAgregarC;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrdenID;
        private System.Windows.Forms.DataGridViewTextBoxColumn FechaS;
        private System.Windows.Forms.DataGridViewTextBoxColumn FechaE;
        private System.Windows.Forms.DataGridViewTextBoxColumn Valor_Total;
        private System.Windows.Forms.DataGridViewTextBoxColumn Proveedor;
        private System.Windows.Forms.DataGridViewTextBoxColumn AdministradorN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
    }
}