﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmContenedor : Form
    {
        public frmContenedor()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            abrirFormInPanel(new Inicio());
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwmd, int wnsg, int wparam, int lparam);

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (panel_menuVertical.Width == 250)
            {
                panel_menuVertical.Width = 57;
            }
            else
            {
                panel_menuVertical.Width = 250;
            }
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void picture_maximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            picture_minimizar.Visible = true;
            picture_maximizar.Visible = false;
        }

        private void picture_minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            picture_minimizar.Visible = false;
            picture_maximizar.Visible = true;
        }

        private void picture_ocultar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel_barraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle,0x112,0xf012,0);
        }

        private void abrirFormInPanel(Object FormHijo)
        {
            if (this.panel_Contenedor.Controls.Count > 0)
                this.panel_Contenedor.Controls.RemoveAt(0);
            Form fh= FormHijo as Form;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.panel_Contenedor.Controls.Add(fh);
            this.panel_Contenedor.Tag = fh;
            fh.Show();
        }
        private void btnAdmins_1_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new frmAdministrador());

        }

        private void btnClientes_2_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new frmClientes());
        }

        private void bntVentas_3_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new frmVentas());
        }

        private void btnProveedores_4_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new frmProveedor());
        }

        private void btnProductos_5_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new frmProductos());
        }

        private void btnOrdenCompra_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new frmOrdenCompra());
        }

        private void btn0Menú_Click(object sender, EventArgs e)
        {

            abrirFormInPanel(new Inicio());
        }

        private void panel_barraTitulo_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
