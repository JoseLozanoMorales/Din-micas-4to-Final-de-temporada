﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;
using System.Drawing.Printing;
using System.Reflection;

namespace BDSistemaVentas
{
    public partial class frmDetalleVenta : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        int ClientexPag = 40;
        int Bandera = 0;
        public frmDetalleVenta()
        {
            InitializeComponent();
            detalleV();
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        private void detalleV()
        {
            int OrdenID = csGlobalVariablesDV.MiVariableGlobalDV;
            cadena = $"select V.VentaID, P.ProductoID, P.Nombre, C.Nombre, V.Cantidad, I.Porcentaje, V.Subtotal, P.Precio_Venta, V.Precio_VentaF from IVA I inner join Producto P on I.IvaID=P.IVAID inner join Categoria C on P.CategoriaID=C.CategoriaID inner join Detalle_Venta V on P.ProductoID=V.ProductoID where V.VentaID = {OrdenID}";
            DataSet ds = sqlCon.retornarregristros(cadena);
            dgbDetalleV.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores[j] = fila[j];
                }

                dgbDetalleV.Rows.Add(valores);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            try
            {
                prdImprimir = new PrintDocument();
                PrinterSettings ps = new PrinterSettings();
                prdImprimir.PrinterSettings = ps;
                prdImprimir.PrintPage += Imprimir;
                prdImprimir.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir: " + ex.Message);
            }
        }
        private void Imprimir(object sender, PrintPageEventArgs e)
        {
            float y = 390;
            int id = csGlobalVariablesDV.MiVariableGlobalDV;
            string fecha = csDatosVentas.Fecha;
            string cliente = csDatosVentas.cliente;
            string proveedor = csDatosVentas.Administrador;
            string subt = csDatosVentas.Subtotal;
            string total = csDatosVentas.Ventatotal;
            //e.Graphics.DrawImage(imlImagenes.Images[0], new RectangleF(100, 0, imlImagenes.Images[0].Width / 2, imlImagenes.Images[0].Height / 2));
            Font fuente = new Font("Arial", 20, FontStyle.Bold);
            e.Graphics.DrawString("Wachiturros Center", fuente, Brushes.BlueViolet, new RectangleF(275, 20, 300, 40));
            fuente = new Font("Arial", 12, FontStyle.Bold);
            e.Graphics.DrawString("Factura:", fuente, Brushes.Black, new RectangleF(0, 100, 90, 50));
            e.Graphics.DrawString($"{id}", fuente, Brushes.Black, new RectangleF(110, 100, 130, 50));
            e.Graphics.DrawString("Fecha:", fuente, Brushes.Black, new RectangleF(0, 140, 90, 50));
            e.Graphics.DrawString($"{fecha}", fuente, Brushes.Black, new RectangleF(110, 140, 130, 50));
            e.Graphics.DrawString("Cliente:", fuente, Brushes.Black, new RectangleF(0, 180, 90, 50));
            e.Graphics.DrawString($"{cliente}", fuente, Brushes.Black, new RectangleF(110, 180, 130, 50));
            e.Graphics.DrawString("Vendedor:", fuente, Brushes.Black, new RectangleF(0, 220, 90, 50));
            e.Graphics.DrawString($"{proveedor}", fuente, Brushes.Black, new RectangleF(110, 220, 130, 50));
            fuente = new Font("Arial", 14, FontStyle.Bold);
            e.Graphics.DrawString("DETALLE", fuente, Brushes.Red, new RectangleF(0, 280, 200, 20));
            fuente = new Font("Arial", 12, FontStyle.Bold);
            e.Graphics.DrawString("Producto.", fuente, Brushes.Black, new RectangleF(30, 340, 180, 20));
            e.Graphics.DrawString("Cantidad.", fuente, Brushes.Black, new RectangleF(150, 340, 75, 20));
            e.Graphics.DrawString("Precio Unitario.", fuente, Brushes.Black, new RectangleF(250, 340, 300, 20));
            e.Graphics.DrawString("SubTotal:", fuente, Brushes.Black, new RectangleF(400, 340, 300, 20));
            e.Graphics.DrawString("Iva.", fuente, Brushes.Black, new RectangleF(650, 340, 150, 20));
            e.Graphics.DrawString("Precio Final.", fuente, Brushes.Black, new RectangleF(710, 340, 150, 20));
            e.Graphics.DrawLine(new Pen(Color.Black, 1), 0, 380, 800, 380);


            fuente = new Font("Arial", 12, FontStyle.Regular);
            cadena = $"select P.Nombre, D.Cantidad, P.Precio_Venta, D.Subtotal, I.Porcentaje, D.Precio_VentaF from Iva I inner join Producto P on I.IvaID=P.IVAID inner join Detalle_Venta D on P.ProductoID=D.ProductoID INNER JOIN Venta VEN on D.VentaID=VEN.VentaID INNER JOIN Cliente cli on VEN.ClienteID=cli.ClienteID where D.VentaID = {id}";
            DataTable dt = sqlCon.retornarregistro(cadena);
            for (int i = 0; Bandera < dt.Rows.Count && i < ClientexPag; i++, Bandera++)
            {
                e.Graphics.DrawString((Bandera + 1).ToString(), fuente, Brushes.Black, new RectangleF(0, y, 40, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Nombre"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(30, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Cantidad"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(150, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Precio_Venta"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(250, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Subtotal"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(400, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Porcentaje"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(650, y, 75, 20));
                e.Graphics.DrawString(dt.Rows[Bandera]["Precio_VentaF"].ToString().Trim(), fuente, Brushes.Black, new RectangleF(710, y, 75, 20));
                y += 20;
            }
            e.HasMorePages = Bandera < dt.Rows.Count;
            fuente = new Font("Arial", 14, FontStyle.Bold);
            e.Graphics.DrawString("RESUMEN:", fuente, Brushes.Red, new RectangleF(0, y + 30, 200, 20));
            fuente = new Font("Arial", 12, FontStyle.Bold);
            e.Graphics.DrawString("Sub Total:", fuente, Brushes.Black, new RectangleF(0, y + 80, 180, 20));
            e.Graphics.DrawString($"{subt}", fuente, Brushes.Black, new RectangleF(110, y + 80, 130, 50));
            e.Graphics.DrawString("Monto Final:", fuente, Brushes.Black, new RectangleF(0, y + 110, 150, 20));
            e.Graphics.DrawString($"{total}", fuente, Brushes.Black, new RectangleF(110, y + 110, 130, 50));

        }

        private void dgbDetalleV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
