﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;
using System.Security.Cryptography;

namespace BDSistemaVentas
{
    public partial class InsertarDetalleVenta : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        int cont = 0;
        public InsertarDetalleVenta()
        {
            InitializeComponent();
            CargarClientes();
            CargarAdmin();
            CargarProducto();
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int cant = int.Parse(txtCantidad.Text);
            string stock = csGlobalVariablesProduct.stock;
            int st = int.Parse(stock);
            if (cant <= st)
            {
                if (cont == 0)
                {
                    int OrdenVentaID = sqlCon.GenerarCodigoUnico("Venta", "VentaID");
                    csGlobalVariablesOrden.MiVariableGlobalOrden = OrdenVentaID;
                    int cliente = int.Parse(csGlobalVariablesCliente.MiVariableGlobalCliente);
                    int admin = int.Parse(csGlobalVariablesAdmin.MiVariableGlobalAdmin);
                    string fechaemision = dtpFechaE_PlazoI.Value.ToString("yyyy-MM-dd");
                    string valores = $"{OrdenVentaID}, '{fechaemision}', {cliente}, {admin}";
                    sqlCon.insertarDatosVenta(valores);
                    foreach (Control control in gmbOrden.Controls)
                    {
                        control.Enabled = false;
                    }
                }
                cont = 1;

                int productoID = int.Parse(csGlobalVariablesProduct.MiVariableGlobalProduct);
                int Cantidadp = int.Parse(txtCantidad.Text);

                int OrdenVentaID1 = csGlobalVariablesOrden.MiVariableGlobalOrden;
                string valoresB = $"{OrdenVentaID1}, {productoID}, {Cantidadp}, 0";
                sqlCon.insertarDatosDetalleVenta(valoresB);
            }
            else
            {
                MessageBox.Show("La cantidad excede el stock del producto");
            }
        }

        private void cmbCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ClienteSelec = cbCliente.SelectedItem.ToString();
            cadena = $"SELECT ClienteID FROM Cliente WHERE Nombre = '{ClienteSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string clientes = ds.Tables[0].Rows[0]["ClienteID"].ToString().Trim();
                csGlobalVariablesCliente.MiVariableGlobalCliente = $"{clientes}";
            }
        }

        private void cmbAdmin_SelectedIndexChanged(object sender, EventArgs e)
        {
            string AdministradorSelec = cbAdmin.SelectedItem.ToString();
            cadena = $"SELECT AdministradorID FROM Administrador WHERE Nombre = '{AdministradorSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string administrador = ds.Tables[0].Rows[0]["AdministradorID"].ToString().Trim();
                csGlobalVariablesAdmin.MiVariableGlobalAdmin = $"{administrador}";
            }
        }

        private void cbProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProductoSeleccionado = cbProducto.SelectedItem.ToString();
            cadena = $"SELECT Precio_Venta FROM Producto WHERE Nombre = '{ProductoSeleccionado}'";
            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                // Asume que la categoría está en la primera fila y columna
                string precioV = ds.Tables[0].Rows[0]["Precio_Venta"].ToString().Trim();
                lblPrecio.Text = $"{precioV}";
                csGlobalVariablesPrecio.MiVariableGlobalPrecio = $"{precioV}";
            }
            else
            {
                lblPrecio.Text = "Precio no encontrada";
            }

            cadena = $"select V.Porcentaje from Producto P inner join IVA V ON P.IVAID=V.IVAID where P.Nombre =  '{ProductoSeleccionado}'";
            DataSet dx = sqlCon.retornarregristros(cadena);
            if (dx.Tables.Count > 0 && dx.Tables[0].Rows.Count > 0)
            {
                // Asume que la categoría está en la primera fila y columna
                string iva = dx.Tables[0].Rows[0]["Porcentaje"].ToString().Trim();
                lblIVA.Text = $"{iva}";
            }
            else
            {
                lblPrecio.Text = "Porcentaje no encontrada";
            }


            cadena = $"SELECT ProductoID FROM Producto WHERE Nombre = '{ProductoSeleccionado}'";

            DataSet dy = sqlCon.retornarregristros(cadena);
            if (dy.Tables.Count > 0 && dy.Tables[0].Rows.Count > 0)
            {
                string producto = dy.Tables[0].Rows[0]["ProductoID"].ToString().Trim();
                csGlobalVariablesProduct.MiVariableGlobalProduct = $"{producto}";
            }

            cadena = $"SELECT Stock FROM Producto WHERE Nombre = '{ProductoSeleccionado}'";

            DataSet dz = sqlCon.retornarregristros(cadena);
            if (dz.Tables.Count > 0 && dz.Tables[0].Rows.Count > 0)
            {
                string stock = dz.Tables[0].Rows[0]["Stock"].ToString().Trim();
                csGlobalVariablesProduct.stock = $"{stock}";
                lblStock.Text = $"{stock}";
            }
        }
        private void CargarClientes()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Cliente";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbCliente.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbCliente.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void CargarAdmin()
        {
            cadena = "Select Nombre from Administrador";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbAdmin.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbAdmin.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void CargarProducto()
        {
            cadena = "Select Nombre from Producto";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbProducto.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbProducto.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void txtCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtDescuento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void InsertarDetalleVenta_Load(object sender, EventArgs e)
        {

        }

        private void txtCantidad_TextChanged(object sender, EventArgs e)
        {

        }


        private void dtpFechaE_PlazoI_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lblPrecio_Click(object sender, EventArgs e)
        {

        }
    }
}
