﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_1
{
    public partial class frm_Buscar : Form
    {
        string cadena;
        csConexion sqlCon = new csConexion();
        public frm_Buscar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mostrardatosestudiante();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string TipoBusqueda = comboBox1.SelectedItem.ToString();
            csVariablesGlobales.busqueda = TipoBusqueda;
            label2.Text = $"seleccione el {TipoBusqueda}: ";
            CargarDatos();
        }
        private void CargarDatos()
        {
            string TipoBusqueda = csVariablesGlobales.busqueda;
            cadena = $"Select {TipoBusqueda} from Estudiantes";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                comboBox2.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row[TipoBusqueda]))
                    {
                        comboBox2.Items.Add(row[TipoBusqueda].ToString().Trim());
                    }
                }
            }
        }

        private void mostrardatosestudiante()
        {
            string BusquedaS = csVariablesGlobales.busquedaS;
            cadena = $"'{BusquedaS}'";
            DataSet ds = sqlCon.Buscar(cadena);
            dgvEstudiante.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores[j] = fila[j];
                }

                dgvEstudiante.Rows.Add(valores);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string BusquedaSeleccionada = comboBox2.SelectedItem.ToString();
            csVariablesGlobales.busquedaS = BusquedaSeleccionada;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
