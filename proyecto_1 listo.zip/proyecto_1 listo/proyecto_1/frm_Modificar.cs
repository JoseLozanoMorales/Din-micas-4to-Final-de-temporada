﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace proyecto_1
{
    public partial class frm_Modificar : Form
    {
        string cadena;
        csConexion sqlCon = new csConexion();

        public frm_Modificar()
        {
            InitializeComponent();
            CargarDatos();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = csVariablesGlobales.ID;
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            string cedula = txtCedula.Text;
            string fechaN = txtFechaNacimiento.Value.ToString("yyyy-MM-dd");
            string grado = txtGrado.Text;
            decimal promedio = decimal.Parse(txtPromedio.Text);
            cadena = $"{id}, '{nombre}', '{apellido}', '{cedula}', '{fechaN}', '{grado}', {promedio}";
            sqlCon.ModificarDatosEstudiantes(cadena);
            this.Hide();
        }
        private void CargarDatos()
        {
            string TipoBusqueda = csVariablesGlobales.busqueda;
            cadena = $"Select Nombre from Estudiantes";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                comboBox1.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row[$"Nombre"]))
                    {
                        comboBox1.Items.Add(row[$"Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Estudiante = comboBox1.SelectedItem.ToString();
            cadena = $"SELECT IdEstudiante FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet da = sqlCon.retornarregristros(cadena);
            if (da.Tables.Count > 0 && da.Tables[0].Rows.Count > 0)
            {
                string EstudianteID = da.Tables[0].Rows[0]["IdEstudiante"].ToString().Trim();
                csVariablesGlobales.ID = int.Parse(EstudianteID);
            }

            cadena = $"SELECT Nombre FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet db = sqlCon.retornarregristros(cadena);
            if (db.Tables.Count > 0 && db.Tables[0].Rows.Count > 0)
            {
                string Nombre = db.Tables[0].Rows[0]["Nombre"].ToString().Trim();
                txtNombre.Text = Nombre;
            }

            cadena = $"SELECT Apellido FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet dc = sqlCon.retornarregristros(cadena);
            if (dc.Tables.Count > 0 && dc.Tables[0].Rows.Count > 0)
            {
                string Apellido = dc.Tables[0].Rows[0]["Apellido"].ToString().Trim();
                txtApellido.Text = Apellido;
            }

            cadena = $"SELECT Cedula FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet dd = sqlCon.retornarregristros(cadena);
            if (dd.Tables.Count > 0 && dd.Tables[0].Rows.Count > 0)
            {
                string Cedula = dd.Tables[0].Rows[0]["Cedula"].ToString().Trim();
                txtCedula.Text = Cedula;
            }

            cadena = $"SELECT FechaNacimiento FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet de = sqlCon.retornarregristros(cadena);
            if (de.Tables.Count > 0 && de.Tables[0].Rows.Count > 0)
            {
                // Convertir el valor de la base de datos a DateTime
                DateTime fechaNacimiento = Convert.ToDateTime(de.Tables[0].Rows[0]["FechaNacimiento"]);

                // Asignar el valor al DateTimePicker
                txtFechaNacimiento.Value = fechaNacimiento;
            }

            cadena = $"SELECT Grado FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet df = sqlCon.retornarregristros(cadena);
            if (df.Tables.Count > 0 && df.Tables[0].Rows.Count > 0)
            {
                string Grado = df.Tables[0].Rows[0]["Grado"].ToString().Trim();
                txtGrado.Text = Grado;
            }

            cadena = $"SELECT Promedio FROM Estudiantes WHERE Nombre = '{Estudiante}'";

            DataSet dg = sqlCon.retornarregristros(cadena);
            if (dg.Tables.Count > 0 && dg.Tables[0].Rows.Count > 0)
            {
                string Promedio = dg.Tables[0].Rows[0]["Promedio"].ToString().Trim();
                txtPromedio.Text = Promedio;
            }
        }

        private void txtPromedio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
