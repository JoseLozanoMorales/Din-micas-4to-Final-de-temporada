﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_1
{
    internal class csConexion
    {
        SqlConnection conexion;
        SqlCommand cCOM;
        SqlDataAdapter cDA;
        SqlDataReader cDR;
        DataSet cDS;
        DataTable cDT;

        string server;
        string baseDatos;
        string Usuario;
        string Clave;
        string Cadena;

        public string Server
        {
            get { return server; }
            set { server = value; }
        }
        public string BaseDatos
        {
            get { return baseDatos; }
            set { baseDatos = value; }
        }

        public csConexion()
        {
			Server = "JEREMY\\SQLEXPRESS";
			BaseDatos = "Estudiantes";
		}

		public csConexion(string ser, string bd)
		{
			Server = ser;
			BaseDatos = bd;
		}

		public bool abrirConexion()
        {
			try
			{
				conexion = new SqlConnection();
				conexion.ConnectionString = "Server=" + Server + "; Database=" + BaseDatos + ";integrated security=true";
				conexion.Open();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error de apertura");
				return false;
			}

			return true;
		}

        public bool cerrarConexion()
        {
            try
            {
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de cerrado");
                return false;
            }

            return true;
        }

        public int GenerarCodigoUnico(string Tabla, string Campo)
        {
            int nextCode = 1;
            abrirConexion();
            Cadena = $"SELECT {Campo} FROM {Tabla} ORDER BY {Campo}";
            cCOM = new SqlCommand(Cadena, conexion);
            using (SqlDataReader reader = cCOM.ExecuteReader())
            {
                while (reader.Read())
                {
                    int codigoconcurrente = reader.GetInt32(0);
                    if (codigoconcurrente != nextCode)
                        break;
                    nextCode++;
                }
            }
            cerrarConexion();
            return nextCode;
        }

        public DataSet retornarregristros(string sentencia)
        {
            try
            {
                if (sentencia.Length > 0)
                {
                    abrirConexion();
                    cCOM = new SqlCommand(sentencia, conexion);
                    cDA = new SqlDataAdapter(cCOM);
                    cDS = new DataSet("dsRetorna");
                    cDA.Fill(cDS, "dsRetorna");
                    cerrarConexion();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error en acceso de datos");
            }
            return cDS;
        }

        public bool insertarDatosEstudiantes(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"Exec RegistrarEstudiante {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool ModificarDatosEstudiantes(string Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"Exec ActualizarEstudiante {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public bool EliminarDatosEstudiante(int Datos)
        {
            try
            {
                abrirConexion();
                Cadena = $"Exec EliminarEstudiante {Datos}";
                cCOM = new SqlCommand(Cadena, conexion);
                cCOM.ExecuteNonQuery();
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                return false;
            }
            return true;
        }

        public DataSet Buscar(string datos)
        {
            DataSet ds = new DataSet();

            try
            {
                abrirConexion();
                string cadena = $"Exec BuscarEstudiantes {datos}";
                using (SqlCommand comando = new SqlCommand(cadena, conexion))
                {
                    SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                    adaptador.Fill(ds); // Llena el DataSet con los resultados de la consulta
                }
                cerrarConexion();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

            return ds;
        }
    }
}
