﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_1
{
    public partial class Form1 : Form
    {
        string cadena;
        csConexion sqlCon = new csConexion();

        public Form1()
        {
            InitializeComponent();
            mostrardatosestudiante();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            frm_Buscar buscar = new frm_Buscar();
            buscar.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            frm_Agregar agregar = new frm_Agregar();
            agregar.ShowDialog();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            frm_Modificar modificar = new frm_Modificar();
            modificar.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void mostrardatosestudiante()
        {
            cadena = "select * from Estudiantes";
            DataSet ds = sqlCon.retornarregristros(cadena);
            dgvEstudiante.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores[j] = fila[j];
                }

                dgvEstudiante.Rows.Add(valores);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            mostrardatosestudiante();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgvEstudiante.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvEstudiante.Rows[selectedRowIndex];
                int estudianteID = Convert.ToInt32(selectedRow.Cells["Estudiante_ID"].Value);
                sqlCon.EliminarDatosEstudiante(estudianteID);
                mostrardatosestudiante();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione un estudiante");
            }
        }
    }
}
