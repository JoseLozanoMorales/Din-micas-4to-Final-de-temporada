﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_1
{
    public partial class frm_Agregar : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public frm_Agregar()
        {
            InitializeComponent();
        }

        private void frm_Agregar_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if(txtNombre.Text == "" || txtApellido.Text == "" || txtCedula.Text == "" || txtGrado.Text == "" || txtPromedio.Text == "")
            {
                MessageBox.Show("Rellene todos los campos");
            }
            else
            {
                if (txtCedula.Text.Length == 10)
                {
                    int clienteID = sqlCon.GenerarCodigoUnico("Estudiantes", "IdEstudiante");
                    string nombre = txtNombre.Text;
                    string apellido = txtApellido.Text;
                    string cedula = txtCedula.Text;
                    string fechaN = txtFechaNacimiento.Value.ToString("yyyy-MM-dd");
                    string grado = txtGrado.Text;
                    decimal promedio = decimal.Parse(txtPromedio.Text);
                    cadena = $"{clienteID}, '{nombre}', '{apellido}', '{cedula}', '{fechaN}', '{grado}', {promedio}";
                    sqlCon.insertarDatosEstudiantes(cadena);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Son 10 digitos en la cedula");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void txtPromedio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPromedio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
