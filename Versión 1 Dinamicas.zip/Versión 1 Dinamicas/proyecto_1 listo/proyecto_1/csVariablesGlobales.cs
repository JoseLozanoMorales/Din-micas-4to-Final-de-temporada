﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyecto_1
{
    internal class csVariablesGlobales
    {
        public static int ID;
        public static string busqueda;
        public static string busquedaS;
    }
}
