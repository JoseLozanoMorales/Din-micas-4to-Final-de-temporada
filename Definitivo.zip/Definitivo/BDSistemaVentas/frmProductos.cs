﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BDSistemaVentas
{
    public partial class frmProductos : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public frmProductos()
        {
            InitializeComponent();
            mostrardatosproductos();
            CargarProducto();
        }


        private void btn_InsertarDatosProductos(object sender, EventArgs e)
        {
            frminsertarProductos insertarProductos = new frminsertarProductos();
            insertarProductos.ShowDialog();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            
            string nombre = csGlobalVariablesProduct.MiVariableGlobalProduct;
            
            if (nombre != "")
            {
                
                cadena = $"Select * from Producto where Nombre = '{nombre}'";
                DataSet ds = sqlCon.retornarregristros(cadena);
                dgvProductos.Rows.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    DataRow fila = ds.Tables[0].Rows[i];
                    object[] valores = new object[fila.ItemArray.Length];

                    for (int j = 0; j < fila.ItemArray.Length; j++)
                    {
                        valores[j] = fila[j];
                    }

                    dgvProductos.Rows.Add(valores);
                }
            }
            else
            {
                mostrardatosproductos();
                MessageBox.Show("no hay que buscar");
            }
        }

        private void mostrardatosproductos()
        {
            cadena = "select P.ProductoID, P.Nombre, P.Stock, P.Precio_Venta, P.Costo_promedio, P.Descripcion, C.Nombre, I.Porcentaje from Producto P inner join IVA I on P.IVAID=I.IvaID inner join Categoria C on P.CategoriaID=C.CategoriaID";
            DataSet ds5 = sqlCon.retornarregristros(cadena);
            dgvProductos.Rows.Clear();
            for (int i = 0; i < ds5.Tables[0].Rows.Count; i++)
            {
                DataRow fila5 = ds5.Tables[0].Rows[i];
                object[] valores5 = new object[fila5.ItemArray.Length];

                for (int j = 0; j < fila5.ItemArray.Length; j++)
                {
                    valores5[j] = fila5[j];
                }

                dgvProductos.Rows.Add(valores5);
            }
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgvProductos.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvProductos.Rows[selectedRowIndex];
                int productoID = Convert.ToInt32(selectedRow.Cells["ProductoID"].Value);
                sqlCon.eliminarDatosProducto(productoID);
                mostrardatosproductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione un producto");
            }
        }

        private void cbProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProductoSeleccionado = cbProducto.SelectedItem.ToString();
            cadena = $"SELECT Nombre FROM Producto WHERE Nombre = '{ProductoSeleccionado}'";

            DataSet dy = sqlCon.retornarregristros(cadena);
            if (dy.Tables.Count > 0 && dy.Tables[0].Rows.Count > 0)
            {
                string producto = dy.Tables[0].Rows[0]["Nombre"].ToString().Trim();
                csGlobalVariablesProduct.MiVariableGlobalProduct = $"{producto}";
            }
        }
        private void CargarProducto()
        {
            cadena = "Select Nombre from Producto";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbProducto.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbProducto.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
