﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class IdeaCrearAdmin : Form
    {
        csConexion sqlCon = new csConexion();
        public IdeaCrearAdmin()
        {
            InitializeComponent();
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtCiudad.Text == "" || txtPais.Text == "" || txtCedula.Text == "" || txtNombre.Text == "" || txtApellido.Text == "" || txtCorreo.Text == "" || txtTelefono.Text == "" || txtDireccion.Text == "" || txtNombre_Perfil.Text == "" || txtContrasenia.Text == "")
            {
                MessageBox.Show("Datos faltantes");
            }
            else if (txtCedula.Text.Length != 10)
            {
                MessageBox.Show("Solo 10 digitos en la cedula");
            }
            else
            {
                //codigo unico
                int AdministradorID = sqlCon.GenerarCodigoUnico("Administrador", "AdministradorID");
                string Nombre = txtNombre.Text;
                string Apellido = txtApellido.Text;
                string Correo = txtCorreo.Text;
                string cedula = txtCedula.Text;
                string telefono = txtTelefono.Text;
                string Direccion = txtDireccion.Text;
                string ciudad = txtCiudad.Text;
                string pais = txtPais.Text;
                string nombrep = txtNombre_Perfil.Text;
                string contrasenia = txtContrasenia.Text;
                //atributos de Administrador
                //string camposA = "AdministradorID,Nombre,Apellido,Correo_electronico,Cedula,Telefono,Direccion,Ciudad,Pais,Nombreusuario,Contraseña";
                string valoresA = $"{AdministradorID},'{Nombre}', '{Apellido}', '{Correo}', '{cedula}', '{telefono}', '{Direccion}', '{ciudad}', '{pais}', '{nombrep}', '{contrasenia}'";
                sqlCon.insertarDatosAdmin(valoresA);
                MessageBox.Show("Datos ingresados correctamente");
                this.Hide();
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCiudad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPais_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
