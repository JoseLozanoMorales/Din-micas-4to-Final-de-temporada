﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BDSistemaVentas
{
    public partial class frmAdministrador : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public frmAdministrador()
        {
            InitializeComponent();
            mostrardatosAdmin();
            CargarAdmin();
        }

        private void btn_InsertarDatosAdmin_Click(object sender, EventArgs e)
        {
            IdeaCrearAdmin crearAdmin = new IdeaCrearAdmin();
            crearAdmin.Show();

        }

        private void btnNuevoAdmin_Click(object sender, EventArgs e)
        {
            IdeaCrearAdmin frm = new IdeaCrearAdmin();
            frm.ShowDialog();
            
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string nombre = csGlobalVariablesAdmin.MiVariableGlobalAdmin;
            
            if (cbAdmin.SelectedIndex !=  -1)
            {
                cadena = $"Select * from Administrador where AdministradorID = '{nombre}'";
                DataSet ds = sqlCon.retornarregristros(cadena);
                dgvAdmins.Rows.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    DataRow fila = ds.Tables[0].Rows[i];
                    object[] valores = new object[fila.ItemArray.Length];

                    for (int j = 0; j < fila.ItemArray.Length; j++)
                    {
                        valores[j] = fila[j];
                    }

                    dgvAdmins.Rows.Add(valores);
                }
            }
            else
            {
                mostrardatosAdmin();
                MessageBox.Show("no hay que buscar");
            }
        }

        private void mostrardatosAdmin()
        {
            csConexion sqlCon = new csConexion();
            string cadena1 = "Select * from Administrador";
            DataSet ds1 = sqlCon.retornarregristros(cadena1);
            dgvAdmins.Rows.Clear();
            for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
            {
                DataRow fila1 = ds1.Tables[0].Rows[i];
                object[] valores1 = new object[fila1.ItemArray.Length];

                for (int j = 0; j < fila1.ItemArray.Length; j++)
                {
                    valores1[j] = fila1[j];
                }

                dgvAdmins.Rows.Add(valores1);
            }
        }
        private void CargarAdmin()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Administrador";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbAdmin.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbAdmin.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void txtBuscarA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cbAdmin_SelectedIndexChanged(object sender, EventArgs e)
        {
            string AdministradorSelec = cbAdmin.SelectedItem.ToString();

            cadena = $"SELECT AdministradorID FROM Administrador WHERE Nombre = '{AdministradorSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string administrador = ds.Tables[0].Rows[0]["AdministradorID"].ToString().Trim();
                csGlobalVariablesAdmin.MiVariableGlobalAdmin = $"{administrador}";
            }
        }

        private void btnEliminarAdmin_Click(object sender, EventArgs e)
        {

        }
    }
}
