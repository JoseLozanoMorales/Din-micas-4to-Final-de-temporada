﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmClientes : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public frmClientes()
        {
            InitializeComponent();
            mostrardatosClientes();
            CargarClientes();
        }

        private void btn_InsertarDatosClientes_Click(object sender, EventArgs e)
        {
            CrearCliente crearCliente = new CrearCliente();
            crearCliente.ShowDialog(); // Muestra el nuevo formulario y bloquea el principal
        }

        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            CrearCliente cliente = new CrearCliente();
            cliente.ShowDialog();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string id = csGlobalVariablesCliente.MiVariableGlobalCliente;
            if (cbCliente.SelectedIndex != -1)
            {
                cadena = $"Select * from Cliente where ClienteID= '{id}'";
                DataSet ds = sqlCon.retornarregristros(cadena);
                dgvClientes.Rows.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    DataRow fila = ds.Tables[0].Rows[i];
                    object[] valores = new object[fila.ItemArray.Length];

                    for (int j = 0; j < fila.ItemArray.Length; j++)
                    {
                        valores[j] = fila[j];
                    }

                    dgvClientes.Rows.Add(valores);
                }
            }
            else
            {
                mostrardatosClientes();
                MessageBox.Show("no hay que buscar");
            }
        }
        private void mostrardatosClientes()
        {
            cadena = "Select * from Cliente";
            DataSet ds2 = sqlCon.retornarregristros(cadena);
            dgvClientes.Rows.Clear();
            for (int i = 0; i < ds2.Tables[0].Rows.Count; i++)
            {
                DataRow fila2 = ds2.Tables[0].Rows[i];
                object[] valores2 = new object[fila2.ItemArray.Length];

                for (int j = 0; j < fila2.ItemArray.Length; j++)
                {
                    valores2[j] = fila2[j];
                }

                dgvClientes.Rows.Add(valores2);
            }
        }

        private void txtBuscarC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cbCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ClienteSelec = cbCliente.SelectedItem.ToString();
            cadena = $"SELECT ClienteID FROM Cliente WHERE Nombre = '{ClienteSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string clientes = ds.Tables[0].Rows[0]["ClienteID"].ToString().Trim();
                csGlobalVariablesCliente.MiVariableGlobalCliente = $"{clientes}";
            }
        }
        private void CargarClientes()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Cliente";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbCliente.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbCliente.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgvClientes.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvClientes.Rows[selectedRowIndex];
                int clienteID = Convert.ToInt32(selectedRow.Cells["ClienteID"].Value);
                sqlCon.elininarDatosCliente(clienteID);
                mostrardatosClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione un cliente");
            }
        }
    }
}
