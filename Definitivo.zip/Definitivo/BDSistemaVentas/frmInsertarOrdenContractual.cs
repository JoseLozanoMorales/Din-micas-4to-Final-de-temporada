﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmInsertarOrdenContractual : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        int cont = 0;
        public frmInsertarOrdenContractual()
        {
            InitializeComponent();
            CargarProveedores();
            CargarAdmin();
            CargarProducto();
        }

        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            
            int cantP = int.Parse(txtCantidadP.Text);
            int cantE = int.Parse(txtCantidadE.Text);
            string precioV = csGlobalVariablesPrecio.MiVariableGlobalPrecio;
            
            if (cantP >= cantE)
            {
                decimal precioC = decimal.Parse(txtPrecioC.Text);
                Decimal p = decimal.Parse(precioV);
                if (precioC < p)
                {
                    if (cont == 0)
                    {
                        foreach (Control control in cmbOrden.Controls)
                        {
                            control.Enabled = false;
                        }
                        int OrdenID = sqlCon.GenerarCodigoUnico("Orden_Contractual", "OrdenID");
                        csGlobalVariablesOrden.MiVariableGlobalOrden = OrdenID;
                        string proveedorI = csGlobalVariablesProveedor.MiVariableGlobalProveedor;
                        string adminI = csGlobalVariablesAdmin.MiVariableGlobalAdmin;
                        string fechaemision = dtpFechaEmision.Value.ToString("yyyy-MM-dd");
                        string fechaentrega = dtpFechaEntrega.Value.ToString("yyyy-MM-dd");
                        string valoresA = $"{OrdenID},'{fechaemision}', '{fechaentrega}', {proveedorI}, {adminI}";
                        sqlCon.insertarDatosOrdenC(valoresA);
                    }
                    cont = 1;

                    string productoID = csGlobalVariablesProduct.MiVariableGlobalProduct;
                    int Cantidadp = int.Parse(txtCantidadP.Text);
                    int CantidadE = int.Parse(txtCantidadE.Text);
                    decimal Precioc = decimal.Parse(txtPrecioC.Text);
                    int OrdenID1 = csGlobalVariablesOrden.MiVariableGlobalOrden;
                    string valoresB = $"{OrdenID1}, {productoID}, {Cantidadp}, {CantidadE}, {Precioc}";
                    sqlCon.insertarDatosDetalleC(valoresB);
                    necesitado();
                }
                else
                {
                    MessageBox.Show("El precio de compra es superior al de la venta");
                }
            }
            else
            {
                MessageBox.Show("La cantidad entregada no puede ser superior a la cantidad solicitada");
            }
            
        }

        private void cbProveedores_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProveedorSelec = cbProveedores.SelectedItem.ToString();
            cadena = $"SELECT ProveedorID FROM Proveedor WHERE Nombre = '{ProveedorSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string proveedor = ds.Tables[0].Rows[0]["ProveedorID"].ToString().Trim();
                csGlobalVariablesProveedor.MiVariableGlobalProveedor = $"{proveedor}";
            }
        }

        private void cbAdmin_SelectedIndexChanged(object sender, EventArgs e)
        {
            string AdministradorSelec = cbAdmin.SelectedItem.ToString();

            cadena = $"SELECT AdministradorID FROM Administrador WHERE Nombre = '{AdministradorSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string administrador = ds.Tables[0].Rows[0]["AdministradorID"].ToString().Trim();
                csGlobalVariablesAdmin.MiVariableGlobalAdmin = $"{administrador}";
            }
        }

        private void cbProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProductoSelec = cbProducto.SelectedItem.ToString();
            cadena = $"SELECT ProductoID FROM Producto WHERE Nombre = '{ProductoSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string producto = ds.Tables[0].Rows[0]["ProductoID"].ToString().Trim();
                csGlobalVariablesProduct.MiVariableGlobalProduct = $"{producto}";
            }

            cadena = $"SELECT Precio_Venta FROM Producto WHERE Nombre = '{ProductoSelec}'";
            DataSet dX = sqlCon.retornarregristros(cadena);
            if (dX.Tables.Count > 0 && dX.Tables[0].Rows.Count > 0)
            {
                // Asume que la categoría está en la primera fila y columna
                string precioV = dX.Tables[0].Rows[0]["Precio_Venta"].ToString().Trim();
                csGlobalVariablesPrecio.MiVariableGlobalPrecio = $"{precioV}";
            }
        }
        private void CargarProveedores()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Proveedor";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbProveedores.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbProveedores.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void CargarAdmin()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Administrador";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbAdmin.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbAdmin.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }
        private void CargarProducto()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Producto";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbProducto.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbProducto.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void txtPrecioC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',' && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCantidadP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCantidadE_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void frmInsertarOrdenContractual_Load(object sender, EventArgs e)
        {
            necesitado();
        }
        private void necesitado()
        {
            cadena = "SELECT dbo.ProductosAgotados();";
            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                lblProducto.Text = ds.Tables[0].Rows[0][0].ToString();
                csGlobalVariablesProduct.MiVariableGlobalProduct = lblProducto.Text;
            }
            string producto = csGlobalVariablesProduct.MiVariableGlobalProduct;

            cadena = $"select Stock from Producto where Nombre = '{producto}'";
            DataSet dx = sqlCon.retornarregristros(cadena);
            if (dx.Tables.Count > 0 && dx.Tables[0].Rows.Count > 0)
            {
                string stock = dx.Tables[0].Rows[0]["Stock"].ToString().Trim();
                lblStock.Text = $"{stock}";

            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
