﻿CREATE DATABASE [Sistema de Venta Wachiturros]
Use [Sistema de Venta Wachiturros]

CREATE TABLE Administrador (
    AdministradorID INT PRIMARY KEY,
    Nombre VARCHAR(55) NOT NULL,
    Apellido VARCHAR(55) NOT NULL,
    Correo_electronico VARCHAR(50) NOT NULL,
    Cedula CHAR(10) NOT NULL,
    Telefono CHAR(10) NOT NULL,
    Direccion VARCHAR(255) NOT NULL,
    Ciudad VARCHAR(20) NOT NULL,
    Pais VARCHAR(20) NOT NULL,
    Nombreusuario VARCHAR(50) NOT NULL,
    Contraseña VARBINARY(8000)
);

CREATE TABLE Cliente (
    ClienteID INT PRIMARY KEY,
    Nombre VARCHAR(55) NOT NULL,
    Apellido VARCHAR(55) NOT NULL,
    Correo_electronico VARCHAR(50) NOT NULL,
    Cedula CHAR(10) NOT NULL,
    Telefono CHAR(10) NOT NULL,
    Direccion VARCHAR(255) NOT NULL,
    Ciudad VARCHAR(20) NOT NULL,
    Pais VARCHAR(20) NOT NULL
);

CREATE TABLE Proveedor (
    ProveedorID INT PRIMARY KEY,
    Nombre VARCHAR(40) NOT NULL,
    Ruc CHAR(13) NOT NULL,
    Ciudad VARCHAR(20) NOT NULL,
    Direccion VARCHAR(255) NOT NULL,
    Telefono VARCHAR(12) NOT NULL,
    Correo_electronico VARCHAR(50) NOT NULL,
    Pais VARCHAR(20) NOT NULL
);

CREATE TABLE Categoria (
    CategoriaID INT PRIMARY KEY,
    Nombre VARCHAR(60) NOT NULL,
);

CREATE TABLE IVA (
    IvaID INT PRIMARY KEY,      
    Porcentaje INT NOT NULL DEFAULT 0
);

-----------------------------------------
CREATE TABLE Producto (   -------TRATADO
    ProductoID INT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Stock INT NOT NULL DEFAULT 0,
    Precio_Venta DECIMAL(12, 2) NOT NULL DEFAULT 0,
    Costo_promedio DECIMAL(12, 2) NOT NULL DEFAULT 0,
	Descripcion VARCHAR(355) NOT NULL,
    CategoriaID INT NOT NULL,
    IVAID INT NOT NULL,  
    FOREIGN KEY (CategoriaID) REFERENCES Categoria(CategoriaID),
    FOREIGN KEY (IvaID) REFERENCES IVA(IvaID)
);

CREATE TABLE Venta (              
    VentaID INT PRIMARY KEY,         
    Fecha DATE NOT NULL,
	Subtotal Decimal(12,2)NOT NULL DEFAULT 0,
    Monto_final DECIMAL(12, 2)NOT NULL DEFAULT 0,
    ClienteID INT NOT NULL,
    AdministradorID INT NOT NULL,
    FOREIGN KEY (ClienteID) REFERENCES Cliente(ClienteID),
    FOREIGN KEY (AdministradorID) REFERENCES Administrador(AdministradorID)
);

CREATE TABLE Orden_Contractual (       --TRATADO, AHORA CALCULA EL MONTO FINAL DE ORDEN_CONTRACTUAL EN BASE A DETALLE_ORDEN
    OrdenID INT  PRIMARY KEY,          
    Fecha_Emision DATE NOT NULL,
    Fecha_Entrega DATE NOT NULL,
    Valor_Total DECIMAL(12, 2) NOT NULL DEFAULT 0,
    ProveedorID INT NOT NULL,
    AdministradorID INT NOT NULL,
    FOREIGN KEY (ProveedorID) REFERENCES Proveedor(ProveedorID),
    FOREIGN KEY (AdministradorID) REFERENCES Administrador(AdministradorID)
);

CREATE TABLE Detalle_Orden (     --TRATADO (LA CANTIDAD ENTREGADA SE REFLEJA EN EL STOCK DEL PRODUCTO, ASÍ COMO EL 
    OrdenID INT NOT NULL,        --PRECIO_COMPRA SE REFLEJA EN PRODUCTO
    ProductoID INT NOT NULL,
    Cantidad_Pedida INT NOT NULL DEFAULT 0,
    Cantidad_Entregada INT NOT NULL DEFAULT 0,
    Precio_Compra DECIMAL(12, 2) NOT NULL DEFAULT 0,
    FOREIGN KEY (OrdenID) REFERENCES Orden_Contractual(OrdenID),
    FOREIGN KEY (ProductoID) REFERENCES Producto(ProductoID)
);

CREATE TABLE Detalle_Venta (  
    VentaID INT NOT NULL,
    ProductoID INT NOT NULL,
    Cantidad INT NOT NULL DEFAULT 0,
    Precio_VentaF DECIMAL(12, 2) NOT NULL DEFAULT 0,
    Descuento INT NOT NULL DEFAULT 0,
    FOREIGN KEY (VentaID) REFERENCES Venta(VentaID),
    FOREIGN KEY (ProductoID) REFERENCES Producto(ProductoID)
);

---------------------------------------------------------------------------------------------------------
----------------------------------   PROCEDIMIENTOS PARA CREAR TABLAS     -------------------------------     
---------------------------------------------------------------------------------------------------------


----PROCEDIMIENTO QUE REGISTRA A UN CLIENTE
CREATE PROCEDURE RegistrarCliente
    @ClienteID INT, @Nombre VARCHAR(55), @Apellido VARCHAR(55), @Correo_electronico VARCHAR(50), @Cedula CHAR(10),  
    @Telefono CHAR(10), @Direccion VARCHAR(255), @Ciudad VARCHAR(20),@Pais VARCHAR(20)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Cliente (ClienteID, Nombre, Apellido, Correo_electronico, Cedula, Telefono, Direccion, Ciudad, Pais)
        VALUES (@ClienteID, @Nombre, @Apellido, @Correo_electronico, @Cedula, @Telefono, @Direccion, @Ciudad, @Pais);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

--PROCEDIMIENTO QUE REGISTRA A UN ADMIN

CREATE PROCEDURE RegistrarAdministrador 
    @AdministradorID INT,@Nombre VARCHAR(55), @Apellido VARCHAR(55),  @Correo_electronico VARCHAR(50),   @Cedula CHAR(10), 
    @Telefono CHAR(10), @Direccion VARCHAR(255), @Ciudad VARCHAR(20),  @Pais VARCHAR(20), @Nombreusuario VARCHAR(50), @Contraseña NVARCHAR(30)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Administrador (AdministradorID, Nombre, Apellido, Correo_electronico, Cedula, Telefono, Direccion, Ciudad, Pais, Nombreusuario, Contraseña)
        VALUES (@AdministradorID, @Nombre, @Apellido, @Correo_electronico, @Cedula, @Telefono, @Direccion, @Ciudad, @Pais, @Nombreusuario, ENCRYPTBYPASSPHRASE('password', @Contraseña));

        COMMIT TRANSACTION;

        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

--PROCEDIMIENTO QUE REGISTRA A UN PROVEEDOR
CREATE PROCEDURE RegistrarProveedor
    @ProveedorID INT,@Nombre VARCHAR(40), @Ruc CHAR(13),  @Ciudad VARCHAR(20),  
    @Direccion VARCHAR(255), @Telefono VARCHAR(12),   @Correo_electronico VARCHAR(50),  @Pais VARCHAR(20)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Proveedor (ProveedorID, Nombre, Ruc, Ciudad, Direccion, Telefono, Correo_electronico, Pais)
        VALUES (@ProveedorID, @Nombre, @Ruc, @Ciudad, @Direccion, @Telefono, @Correo_electronico, @Pais);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

--PROCEDIMIENTO QUE REGISRA CATEGORÍA
CREATE PROCEDURE RegistrarCategoria
    @CategoriaID INT, @Nombre VARCHAR(60)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Categoria (CategoriaID, Nombre)
        VALUES (@CategoriaID, @Nombre);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

---PROCEDIMIENTO QUE CREA EL IVA
CREATE PROCEDURE RegistrarIVA
    @IvaID INT, @Porcentaje INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO IVA (IvaID, Porcentaje)
        VALUES (@IvaID, @Porcentaje);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

--REGISTRO PRODUCTO 

CREATE PROCEDURE RegistrarProducto
    @ProductoID INT,@Nombre VARCHAR(50), @Stock INT, @Precio_Venta DECIMAL(12, 2), @Costo_promedio DECIMAL(12, 2),
    @Descripcion VARCHAR(355),@CategoriaID INT,@IVAID INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Producto (ProductoID, Nombre, Stock, Precio_Venta, Costo_promedio, Descripcion, CategoriaID, IVAID)
        VALUES (@ProductoID, @Nombre, @Stock, @Precio_Venta, @Costo_promedio, @Descripcion, @CategoriaID, @IVAID);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;


---REGISTRAR VENTA
CREATE PROCEDURE RegistrarVenta
    @VentaID INT, @Fecha DATE,  @ClienteID INT, @AdministradorID INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Venta (VentaID, Fecha, ClienteID, AdministradorID)
        VALUES (@VentaID, @Fecha, @ClienteID, @AdministradorID);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

--REGISTRAR ORDEN CONTRACTUAL
CREATE PROCEDURE RegistrarOrdenContractual
    @OrdenID INT, @Fecha_Emision DATE, @Fecha_Entrega DATE,@ProveedorID INT, @AdministradorID INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Orden_Contractual (OrdenID, Fecha_Emision, Fecha_Entrega, ProveedorID, AdministradorID)
        VALUES (@OrdenID, @Fecha_Emision, @Fecha_Entrega, @ProveedorID, @AdministradorID);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

--REGISTRAR DETALLE ORDEN
CREATE PROCEDURE RegistrarDetalleOrden
    @OrdenID INT, @ProductoID INT,@Cantidad_Pedida INT, @Cantidad_Entregada INT, 
    @Precio_Compra DECIMAL(12, 2)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Detalle_Orden (OrdenID, ProductoID, Cantidad_Pedida, Cantidad_Entregada, Precio_Compra)
        VALUES (@OrdenID, @ProductoID, @Cantidad_Pedida, @Cantidad_Entregada, @Precio_Compra);

        COMMIT TRANSACTION;
        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;

CREATE PROCEDURE RegistrarDetalleVenta
    @VentaID INT,
    @ProductoID INT,
    @Cantidad INT,
    @Descuento INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Detalle_Venta (VentaID, ProductoID, Cantidad, Descuento)
        VALUES (@VentaID, @ProductoID, @Cantidad, @Descuento);

        COMMIT TRANSACTION;

        SELECT 0 AS Codigo, 'La transacción fue un éxito' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SELECT -1 AS Codigo, ERROR_MESSAGE() AS Mensaje_de_Error;
    END CATCH
END;
------------------------------------------------------------------------------------------
----------------------------------   REGISTRO DE DATOS     -------------------------------     
------------------------------------------------------------------------------------------
EXEC RegistrarCliente 1, 'Juan', 'Perez', 'juan.perez@mail.com', '1234567890', '0998765432', 'Calle Falsa 123', 'Quito', 'Ecuador';
EXEC RegistrarCliente 2, 'Maria', 'Garcia', 'maria.garcia@mail.com', '0987654321', '0998765433', 'Calle Real 456', 'Guayaquil', 'Ecuador';


EXEC RegistrarAdministrador 1, 'Pedro', 'Lopez', 'pedro.lopez@mail.com', '0987654321', '0991234567', 'Calle A', 'Quito', 'Ecuador', 'pedroAdmin', 'Password123';
EXEC RegistrarAdministrador 2, 'Ana', 'Martinez', 'ana.martinez@mail.com', '0987654322', '0999876543', 'Calle B', 'Cuenca', 'Ecuador', 'anaAdmin', 'Password456';

EXEC RegistrarProveedor 1, 'Proveedora GPUs', '1790012345001', 'Quito', 'Calle Las Flores 123', '022456789', 'gpu.supplier@mail.com', 'Ecuador';
EXEC RegistrarProveedor 2, 'Proveedora HDDs', '1890012345002', 'Guayaquil', 'Calle Los Álamos 456', '042123456', 'hdd.supplier@mail.com', 'Ecuador';

EXEC RegistrarCategoria 1, 'Tarjetas Gráficas';
EXEC RegistrarCategoria 2, 'Discos Duros';

EXEC RegistrarIVA 1, 12;  -- 12% de IVA
EXEC RegistrarIVA 2, 0;   -- 0% de IVA (productos exentos)

EXEC RegistrarProducto 1, 'NVIDIA RTX 3080', 10, 1200.00, 1100.00, 'Tarjeta gráfica de alto rendimiento', 1, 1;
EXEC RegistrarProducto 2, 'Seagate BarraCuda 2TB', 20, 85.50, 80.00, 'Disco duro de 2TB', 2, 1;

EXEC RegistrarVenta 1, '2024-09-21', 1, 1;  -- Venta con ClienteID 1 y AdministradorID 1
EXEC RegistrarVenta 2, '2024-09-21', 2, 2;  -- Venta con ClienteID 2 y AdministradorID 2
EXEC RegistrarVenta 3, '2024-09-21', 2, 2;  -- Venta con ClienteID 2 y AdministradorID 2

EXEC RegistrarOrdenContractual 1, '2024-09-01', '2024-09-10', 1, 1;  -- Orden de compra de ProveedorID 1 y AdministradorID 1
EXEC RegistrarOrdenContractual 2, '2024-09-05', '2024-09-15', 2, 2;  -- Orden de compra de ProveedorID 2 y AdministradorID 2
EXEC RegistrarOrdenContractual 3, '2024-09-05', '2024-09-15', 2, 2;  -- Orden de compra de ProveedorID 2 y AdministradorID 2


EXEC RegistrarDetalleOrden 1, 1, 5, 0, 1100.00;  -- OrdenID 1, ProductoID 1, Cantidad Pedida 5, Cantidad Entregada 0
EXEC RegistrarDetalleOrden 1, 2, 10, 0, 80.00;   -- OrdenID 1, ProductoID 2, Cantidad Pedida 10, Cantidad Entregada 0
EXEC RegistrarDetalleOrden 3, 2, 18, 18, 70.00;   -- OrdenID 1, ProductoID 2, Cantidad Pedida 10, Cantidad Entregada 0



EXEC RegistrarDetalleVenta 1, 1, 2, 10;  -- VentaID 1, ProductoID 1, Cantidad 2, Descuento 10%
EXEC RegistrarDetalleVenta 2, 2, 1, 5;   -- VentaID 2, ProductoID 2, Cantidad 1, Descuento 5%
EXEC RegistrarDetalleVenta 2, 2, 4, 5;   -- VentaID 2, ProductoID 2, Cantidad 1, Descuento 5%
EXEC RegistrarDetalleVenta 3, 1, 2, 5;   -- VentaID 2, ProductoID 2, Cantidad 1, Descuento 5%

Select * from Producto
Select * from Venta
Select * from Orden_Contractual
Select * from Detalle_Venta
Select * from Detalle_Orden
Select * from Categoria
Select * from Cliente
Select * from IVA
Select * from Proveedor











--------------------------------------------------------------------------------------------------------------
--------------------------------------------  CONTROLES CON TRIGGERS     -------------------------------------     
--------------------------------------------------------------------------------------------------------------

----TRIGGER QUE CONTROLA EL SOTCK DEL PRODUCTO(FUNCIONA EN BASE A LA CANTIDAD ENTREGADA DEL PROVEEDOR)
CREATE TRIGGER CalcularStock
ON Detalle_Orden
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE Producto
    SET Stock = Stock + (
        SELECT SUM(Cantidad_Entregada)
        FROM Detalle_Orden do
        WHERE do.ProductoID = Producto.ProductoID
    );
END;


----TRIGGER QUE HAGA EL CÁLCULO PARA OBTENER EL COSTO_PROMEDIO (TABLA PRODUCTO)-->(PRECIO COMPRA * CANTIDAD ENTREGADA)/CANTIDAD ENTREGADA
CREATE TRIGGER CalcularCostoPromedioProducto
ON Detalle_Orden
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE Producto
    SET Costo_promedio = (
        SELECT SUM(Precio_Compra * Cantidad_Entregada) / SUM(Cantidad_Entregada)
        FROM Detalle_Orden
        WHERE Detalle_Orden.ProductoID = Producto.ProductoID
    )
END;


---TRIGGER QUE CALCULA Y CONTROLA EL PRECIO_VENTAF(FINAL) UNITARIO DEL PRODUCTO PERO CON IVA Y DESCUENTO INCLUÍDO
CREATE TRIGGER CalcularPrecioVentaF
ON Detalle_Venta
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE dv
    SET dv.Precio_VentaF = (p.Precio_Venta * (1 + (iva.Porcentaje / 100))) * (1 - (dv.Descuento / 100.0))
    FROM Detalle_Venta dv
    INNER JOIN Producto p ON dv.ProductoID = p.ProductoID
    INNER JOIN IVA iva ON p.IVAID = iva.IVAID;
END;


----TRIGGER QUE REDUCE EL STOCK AL HACER LA VENTA DEL PRODUCTO(ADEMÁS, CONTROLA QUE EL STOCK NO SEA NEGATIVO)
CREATE TRIGGER ReducirStock
ON Detalle_Venta
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Producto
    SET Stock = Stock - dv.Cantidad
    FROM Producto p
    INNER JOIN Detalle_Venta dv ON p.ProductoID = dv.ProductoID;

    IF EXISTS (SELECT 1 FROM Producto WHERE Stock < 0)
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR ('El stock no puede ser negativo', 16, 1);
    END
END;


---TRIGGER QUE CALCULA EL SUBTOTAL DE LA VENTA(ES DECIR, QUE TOMA EL PRECIO NETO UNITARIO DE LA TABLA PRODUCTO Y LO MULTIPLICA POR 
---LA CANTIDAD DE DETALLE_DE_VENTA, AL FINAL SUMA TODO ESO)
CREATE TRIGGER CalcularSubtotalVenta
ON Detalle_Venta
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE Venta
    SET Subtotal = (
        SELECT SUM(p.Precio_Venta * dv.Cantidad)
        FROM Detalle_Venta dv
        INNER JOIN Producto p ON dv.ProductoID = p.ProductoID
        WHERE dv.VentaID = Venta.VentaID
    )
    FROM Venta
    WHERE Venta.VentaID IN (SELECT VentaID FROM Detalle_Venta);
END;



------TRIGGER QUE CALCULA EL MONTO FINAL DE VENTA(ESTO YA INCLUYE LA SUMA DE TODOS LOS PRODUCTOS QUE YA FUERON AFECTADOS POR EL IVA,
------EL DESCUENTO(ES DECIR, EL PRECIO_VENTAF) MULTIPLICADOS POR LA CANTIDAD)
CREATE TRIGGER CalcularMontoFinalVenta
ON Detalle_Venta
AFTER INSERT, UPDATE
AS
BEGIN
    -- Calcular el monto final (con IVA y descuentos)
    UPDATE Venta
    SET Monto_final = ISNULL((
        SELECT SUM(dv.Precio_VentaF * dv.Cantidad)
        FROM Detalle_Venta dv
        WHERE dv.VentaID = Venta.VentaID
    ), 0)
    WHERE Venta.VentaID IN (SELECT DISTINCT VentaID FROM Detalle_Venta);
END;


------TRIGGER QUE CALCULE EL VALOR TOTAL EN ORDEN_CONTRACTUAL(ES LA SUMA DE : TODOS LOS PRECIOS DEL PRODUCTO DE DETALLE_ORDEN
-----* CANTIDAD ENTREGADA DE DETALLE DE ORDEN)
CREATE TRIGGER CalcularValorTotalOrden
ON Detalle_Orden
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE Orden_Contractual
    SET Valor_Total = (
        SELECT SUM(do.Precio_Compra * do.Cantidad_Entregada)
        FROM Detalle_Orden do
        WHERE do.OrdenID = Orden_Contractual.OrdenID
    );
END;

----TRIGGER QUE CONTROLA LA SITUACIÓN DE QUE NO SE PUEDE TENER MÁS CANTIDAD_ENTREGADA QUE CANTIDAD_SOLICITADA

CREATE TRIGGER ControlarCantidadEntregada
ON Detalle_Orden
INSTEAD OF INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF (SELECT COUNT(*) FROM Detalle_Orden WHERE Cantidad_Entregada > Cantidad_Pedida) > 0
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR ('La cantidad entregada no puede ser mayor que la cantidad solicitada.', 16, 1);
    END
END;




