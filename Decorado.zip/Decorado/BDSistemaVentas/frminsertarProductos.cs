﻿using BDSistemaVentas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BDSistemaVentas
{
    public partial class frminsertarProductos : Form
    {

        csConexion sqlCon = new csConexion();
        string cadena;
        public frminsertarProductos()
        {
            InitializeComponent();
            CargarCategoria();
            CargarIVA();
        }


        private void picture_cerrar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btn_InsertarDatos_Click(object sender, EventArgs e)
        {
            if(txtproducto.Text == "" || txtPrecioV.Text == "" || txtDescripcion.Text == "")
            {
                MessageBox.Show("Ingrese todo los campos");
            }
            else
            {
                int ProductoID = sqlCon.GenerarCodigoUnico("Producto", "ProductoID");
                string valor = csGlobalVariablesCategoria.MiVariableGlobalCategoria;
                string producto = txtproducto.Text;
                string Descripcion = txtDescripcion.Text;
                string precio = txtPrecioV.Text;
                string iva1 = csGlobalVariablesIVA.MiVariableGlobalIVA;
                string valores = $"{ProductoID}, '{producto}', {precio}, '{Descripcion}', '{valor}', {iva1}";
                sqlCon.insertarDatosProducto(valores);
            }
        }
        private void CargarCategoria()
        {
            cadena = "Select Nombre from Categoria";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbCategorias.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbCategorias.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }
        private void CargarIVA()
        {
            cadena = "Select Porcentaje from IVA";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbIVA.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Porcentaje"]))
                    {
                        cbIVA.Items.Add(row["Porcentaje"].ToString().Trim());
                    }
                }
            }
        }

        private void cbCategorias_SelectedIndexChanged(object sender, EventArgs e)
        {
            string CategoriaSelec = cbCategorias.SelectedItem.ToString();
            cadena = $"SELECT CategoriaID FROM Categoria WHERE Nombre = '{CategoriaSelec}'";
            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string categoria = ds.Tables[0].Rows[0]["CategoriaID"].ToString().Trim();
                csGlobalVariablesCategoria.MiVariableGlobalCategoria = $"{categoria}";
            }
        }

        private void cbIVA_SelectedIndexChanged(object sender, EventArgs e)
        {
            string IVASelec = cbIVA.SelectedItem.ToString();
            cadena = $"SELECT IvaID FROM IVA WHERE Porcentaje = '{IVASelec}'";
            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string IVA = ds.Tables[0].Rows[0]["IvaID"].ToString().Trim();
                csGlobalVariablesIVA.MiVariableGlobalIVA = $"{IVA}";
            }
        }

        private void txtPrecioV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',' && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; 
            }
        }
    }
}
