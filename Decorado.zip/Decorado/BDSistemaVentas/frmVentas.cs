﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BDSistemaVentas;

namespace BDSistemaVentas
{
    public partial class frmVentas : Form
    {
        csConexion sqlCon = new csConexion();
        string cadena;
        public frmVentas()
        {
            InitializeComponent();
            mostrardatosVenta();
            CargarClientes();
        }

        private void btnDetalleVenta_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgvVentas.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvVentas.Rows[selectedRowIndex];
                int OrdenID = Convert.ToInt32(selectedRow.Cells["IDVenta"].Value);
                DateTime fechaCompleta = Convert.ToDateTime(selectedRow.Cells["Fecha"].Value);
                string fecha = fechaCompleta.ToString("yyyy-MM-dd");
                string cliente = Convert.ToString(selectedRow.Cells["NombreC"].Value);
                string vendedor = Convert.ToString(selectedRow.Cells["NombreA"].Value);
                string subT = Convert.ToString(selectedRow.Cells["SubT"].Value);
                string ventaT = Convert.ToString(selectedRow.Cells["MontoF"].Value);
                csGlobalVariablesDV.MiVariableGlobalDV=OrdenID;
                csDatosVentas.Fecha = fecha;
                csDatosVentas.cliente = cliente;
                csDatosVentas.Administrador = vendedor; 
                csDatosVentas.Subtotal = subT;
                csDatosVentas.Ventatotal = ventaT;
                frmDetalleVenta frm = new frmDetalleVenta();
                frm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione Una Venta");
            }
            
        }

        private void btnNuevaVenta_Click(object sender, EventArgs e)
        {
            InsertarDetalleVenta frm = new InsertarDetalleVenta();
            frm.ShowDialog();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int id = csCliente.ID;
            if (cbCliente.SelectedIndex != -1)
            {
                cadena = $"select V.VentaID, v.Fecha, V.Subtotal, V.Monto_final, C.Nombre, C.Apellido, A.Nombre, A.Apellido from Administrador A inner join Venta V on A.AdministradorID=V.AdministradorID inner join Cliente C on V.ClienteID=C.ClienteID where C.ClienteID = {id}";
                DataSet ds = sqlCon.retornarregristros(cadena);
                dgvVentas.Rows.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    DataRow fila = ds.Tables[0].Rows[i];
                    object[] valores3 = new object[fila.ItemArray.Length];

                    for (int j = 0; j < fila.ItemArray.Length; j++)
                    {
                        valores3[j] = fila[j];
                    }

                    dgvVentas.Rows.Add(valores3);
                }
            }
            else
            {
                mostrardatosVenta();
                MessageBox.Show("no hay que buscar");
            }
        }
        private void mostrardatosVenta()
        {
            cadena = "select V.VentaID, v.Fecha, V.Subtotal, V.Monto_final, C.Nombre, C.Apellido, A.Nombre, A.Apellido from Administrador A inner join Venta V on A.AdministradorID=V.AdministradorID inner join Cliente C on V.ClienteID=C.ClienteID";
            DataSet ds = sqlCon.retornarregristros(cadena);
            dgvVentas.Rows.Clear();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow fila = ds.Tables[0].Rows[i];
                object[] valores3 = new object[fila.ItemArray.Length];

                for (int j = 0; j < fila.ItemArray.Length; j++)
                {
                    valores3[j] = fila[j];
                }

                dgvVentas.Rows.Add(valores3);
            }
        }

        private void cbCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ClienteSelec = cbCliente.SelectedItem.ToString();
            cadena = $"SELECT ClienteID FROM Cliente WHERE Nombre = '{ClienteSelec}'";

            DataSet ds = sqlCon.retornarregristros(cadena);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                string clientes = ds.Tables[0].Rows[0]["ClienteID"].ToString().Trim();
                int ClienteID = int.Parse(clientes);
                csCliente.ID = ClienteID;
            }
        }
        private void CargarClientes()
        {
            csConexion sqlCon = new csConexion();
            cadena = "Select Nombre from Cliente";
            DataSet ds = sqlCon.retornarregristros(cadena);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cbCliente.Items.Clear();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!DBNull.Value.Equals(row["Nombre"]))
                    {
                        cbCliente.Items.Add(row["Nombre"].ToString().Trim());
                    }
                }
            }
        }

        private void btnEliminarAdmin_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedCell = dgvVentas.SelectedCells[0];
                int selectedRowIndex = selectedCell.RowIndex;
                DataGridViewRow selectedRow = dgvVentas.Rows[selectedRowIndex];
                int VentaID = Convert.ToInt32(selectedRow.Cells["IDVenta"].Value);
                sqlCon.eliminarDatosVenta(VentaID);
                mostrardatosVenta();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione un proveedor");
            }
        }
    }
}
