﻿namespace BDSistemaVentas
{
    partial class InsertarDetalleVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InsertarDetalleVenta));
            this.lbl_FVenta_PlazoI = new System.Windows.Forms.Label();
            this.dtpFechaE_PlazoI = new System.Windows.Forms.DateTimePicker();
            this.lblClienteE = new System.Windows.Forms.Label();
            this.lblAdminE = new System.Windows.Forms.Label();
            this.lblProductoE = new System.Windows.Forms.Label();
            this.lblCantidadE = new System.Windows.Forms.Label();
            this.lblivaE = new System.Windows.Forms.Label();
            this.lblPrecioE = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblIVA = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.cbProducto = new System.Windows.Forms.ComboBox();
            this.cbCliente = new System.Windows.Forms.ComboBox();
            this.cbAdmin = new System.Windows.Forms.ComboBox();
            this.panel_barraTitulo = new System.Windows.Forms.Panel();
            this.picture_cerrar = new System.Windows.Forms.PictureBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.gmbOrden = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblStock = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel_barraTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_cerrar)).BeginInit();
            this.gmbOrden.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_FVenta_PlazoI
            // 
            this.lbl_FVenta_PlazoI.AutoSize = true;
            this.lbl_FVenta_PlazoI.Location = new System.Drawing.Point(5, 28);
            this.lbl_FVenta_PlazoI.Name = "lbl_FVenta_PlazoI";
            this.lbl_FVenta_PlazoI.Size = new System.Drawing.Size(120, 16);
            this.lbl_FVenta_PlazoI.TabIndex = 0;
            this.lbl_FVenta_PlazoI.Text = "Fecha de la venta:";
            // 
            // dtpFechaE_PlazoI
            // 
            this.dtpFechaE_PlazoI.Location = new System.Drawing.Point(122, 22);
            this.dtpFechaE_PlazoI.Name = "dtpFechaE_PlazoI";
            this.dtpFechaE_PlazoI.Size = new System.Drawing.Size(200, 25);
            this.dtpFechaE_PlazoI.TabIndex = 1;
            this.dtpFechaE_PlazoI.ValueChanged += new System.EventHandler(this.dtpFechaE_PlazoI_ValueChanged);
            // 
            // lblClienteE
            // 
            this.lblClienteE.AutoSize = true;
            this.lblClienteE.Location = new System.Drawing.Point(55, 55);
            this.lblClienteE.Name = "lblClienteE";
            this.lblClienteE.Size = new System.Drawing.Size(55, 16);
            this.lblClienteE.TabIndex = 2;
            this.lblClienteE.Text = "Cliente:";
            // 
            // lblAdminE
            // 
            this.lblAdminE.AutoSize = true;
            this.lblAdminE.Location = new System.Drawing.Point(57, 91);
            this.lblAdminE.Name = "lblAdminE";
            this.lblAdminE.Size = new System.Drawing.Size(54, 16);
            this.lblAdminE.TabIndex = 3;
            this.lblAdminE.Text = "Admin:";
            // 
            // lblProductoE
            // 
            this.lblProductoE.AutoSize = true;
            this.lblProductoE.Location = new System.Drawing.Point(33, 37);
            this.lblProductoE.Name = "lblProductoE";
            this.lblProductoE.Size = new System.Drawing.Size(67, 16);
            this.lblProductoE.TabIndex = 4;
            this.lblProductoE.Text = "Producto:";
            // 
            // lblCantidadE
            // 
            this.lblCantidadE.AutoSize = true;
            this.lblCantidadE.Location = new System.Drawing.Point(34, 36);
            this.lblCantidadE.Name = "lblCantidadE";
            this.lblCantidadE.Size = new System.Drawing.Size(67, 16);
            this.lblCantidadE.TabIndex = 5;
            this.lblCantidadE.Text = "Cantidad:";
            // 
            // lblivaE
            // 
            this.lblivaE.AutoSize = true;
            this.lblivaE.Location = new System.Drawing.Point(38, 75);
            this.lblivaE.Name = "lblivaE";
            this.lblivaE.Size = new System.Drawing.Size(38, 16);
            this.lblivaE.TabIndex = 6;
            this.lblivaE.Text = "IVA:";
            // 
            // lblPrecioE
            // 
            this.lblPrecioE.AutoSize = true;
            this.lblPrecioE.Location = new System.Drawing.Point(5, 115);
            this.lblPrecioE.Name = "lblPrecioE";
            this.lblPrecioE.Size = new System.Drawing.Size(129, 16);
            this.lblPrecioE.TabIndex = 8;
            this.lblPrecioE.Text = "Precio del producto";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(130, 115);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(37, 16);
            this.lblPrecio.TabIndex = 10;
            this.lblPrecio.Text = "------";
            this.lblPrecio.Click += new System.EventHandler(this.lblPrecio_Click);
            // 
            // lblIVA
            // 
            this.lblIVA.AutoSize = true;
            this.lblIVA.Location = new System.Drawing.Point(99, 75);
            this.lblIVA.Name = "lblIVA";
            this.lblIVA.Size = new System.Drawing.Size(37, 16);
            this.lblIVA.TabIndex = 11;
            this.lblIVA.Text = "------";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(101, 29);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(174, 25);
            this.txtCantidad.TabIndex = 12;
            this.txtCantidad.TextChanged += new System.EventHandler(this.txtCantidad_TextChanged);
            this.txtCantidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantidad_KeyPress);
            // 
            // cbProducto
            // 
            this.cbProducto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProducto.FormattingEnabled = true;
            this.cbProducto.Location = new System.Drawing.Point(107, 34);
            this.cbProducto.Name = "cbProducto";
            this.cbProducto.Size = new System.Drawing.Size(160, 24);
            this.cbProducto.TabIndex = 13;
            this.cbProducto.SelectedIndexChanged += new System.EventHandler(this.cbProducto_SelectedIndexChanged);
            // 
            // cbCliente
            // 
            this.cbCliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCliente.FormattingEnabled = true;
            this.cbCliente.Location = new System.Drawing.Point(116, 55);
            this.cbCliente.Name = "cbCliente";
            this.cbCliente.Size = new System.Drawing.Size(136, 24);
            this.cbCliente.TabIndex = 14;
            this.cbCliente.SelectedIndexChanged += new System.EventHandler(this.cmbCliente_SelectedIndexChanged);
            // 
            // cbAdmin
            // 
            this.cbAdmin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAdmin.FormattingEnabled = true;
            this.cbAdmin.Location = new System.Drawing.Point(116, 91);
            this.cbAdmin.Name = "cbAdmin";
            this.cbAdmin.Size = new System.Drawing.Size(136, 24);
            this.cbAdmin.TabIndex = 15;
            this.cbAdmin.SelectedIndexChanged += new System.EventHandler(this.cmbAdmin_SelectedIndexChanged);
            // 
            // panel_barraTitulo
            // 
            this.panel_barraTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.panel_barraTitulo.Controls.Add(this.picture_cerrar);
            this.panel_barraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_barraTitulo.Location = new System.Drawing.Point(0, 0);
            this.panel_barraTitulo.Name = "panel_barraTitulo";
            this.panel_barraTitulo.Size = new System.Drawing.Size(719, 37);
            this.panel_barraTitulo.TabIndex = 23;
            // 
            // picture_cerrar
            // 
            this.picture_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picture_cerrar.BackColor = System.Drawing.Color.Red;
            this.picture_cerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picture_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("picture_cerrar.Image")));
            this.picture_cerrar.Location = new System.Drawing.Point(687, 12);
            this.picture_cerrar.Name = "picture_cerrar";
            this.picture_cerrar.Size = new System.Drawing.Size(20, 20);
            this.picture_cerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture_cerrar.TabIndex = 1;
            this.picture_cerrar.TabStop = false;
            this.picture_cerrar.Click += new System.EventHandler(this.picture_cerrar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardar.Location = new System.Drawing.Point(99, 243);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(145, 40);
            this.btnGuardar.TabIndex = 59;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // gmbOrden
            // 
            this.gmbOrden.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(93)))), ((int)(((byte)(95)))));
            this.gmbOrden.Controls.Add(this.dtpFechaE_PlazoI);
            this.gmbOrden.Controls.Add(this.lbl_FVenta_PlazoI);
            this.gmbOrden.Controls.Add(this.lblClienteE);
            this.gmbOrden.Controls.Add(this.cbAdmin);
            this.gmbOrden.Controls.Add(this.lblAdminE);
            this.gmbOrden.Controls.Add(this.cbCliente);
            this.gmbOrden.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gmbOrden.Location = new System.Drawing.Point(11, 77);
            this.gmbOrden.Margin = new System.Windows.Forms.Padding(2);
            this.gmbOrden.Name = "gmbOrden";
            this.gmbOrden.Padding = new System.Windows.Forms.Padding(2);
            this.gmbOrden.Size = new System.Drawing.Size(341, 138);
            this.gmbOrden.TabIndex = 60;
            this.gmbOrden.TabStop = false;
            this.gmbOrden.Text = "Datos";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InfoText;
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 460);
            this.panel1.TabIndex = 61;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(620, 1);
            this.panel2.TabIndex = 62;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(93)))), ((int)(((byte)(95)))));
            this.groupBox1.Controls.Add(this.lblStock);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblCantidadE);
            this.groupBox1.Controls.Add(this.lblivaE);
            this.groupBox1.Controls.Add(this.lblPrecioE);
            this.groupBox1.Controls.Add(this.lblPrecio);
            this.groupBox1.Controls.Add(this.lblIVA);
            this.groupBox1.Controls.Add(this.txtCantidad);
            this.groupBox1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(357, 168);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(356, 148);
            this.groupBox1.TabIndex = 65;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pago";
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.Location = new System.Drawing.Point(256, 76);
            this.lblStock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(47, 16);
            this.lblStock.TabIndex = 66;
            this.lblStock.Text = "--------";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 75);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 65;
            this.label4.Text = "Stock:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(93)))), ((int)(((byte)(95)))));
            this.groupBox2.Controls.Add(this.cbProducto);
            this.groupBox2.Controls.Add(this.lblProductoE);
            this.groupBox2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(357, 77);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(356, 75);
            this.groupBox2.TabIndex = 66;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Producto";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InfoText;
            this.panel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Location = new System.Drawing.Point(0, 459);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(719, 1);
            this.panel3.TabIndex = 67;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.InfoText;
            this.panel4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Location = new System.Drawing.Point(718, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 460);
            this.panel4.TabIndex = 68;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.InfoText;
            this.panel5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(719, 1);
            this.panel5.TabIndex = 69;
            // 
            // InsertarDetalleVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(93)))), ((int)(((byte)(90)))));
            this.ClientSize = new System.Drawing.Size(719, 460);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gmbOrden);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.panel_barraTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InsertarDetalleVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InsertarDetalleVenta";
            this.Load += new System.EventHandler(this.InsertarDetalleVenta_Load);
            this.panel_barraTitulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picture_cerrar)).EndInit();
            this.gmbOrden.ResumeLayout(false);
            this.gmbOrden.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_FVenta_PlazoI;
        private System.Windows.Forms.DateTimePicker dtpFechaE_PlazoI;
        private System.Windows.Forms.Label lblClienteE;
        private System.Windows.Forms.Label lblAdminE;
        private System.Windows.Forms.Label lblProductoE;
        private System.Windows.Forms.Label lblCantidadE;
        private System.Windows.Forms.Label lblivaE;
        private System.Windows.Forms.Label lblPrecioE;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblIVA;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.ComboBox cbProducto;
        private System.Windows.Forms.ComboBox cbCliente;
        private System.Windows.Forms.ComboBox cbAdmin;
        private System.Windows.Forms.Panel panel_barraTitulo;
        private System.Windows.Forms.PictureBox picture_cerrar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.GroupBox gmbOrden;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}