﻿namespace BDSistemaVentas
{
    partial class frmContenedor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContenedor));
            this.panel_menuVertical = new System.Windows.Forms.Panel();
            this.btn0Menú = new System.Windows.Forms.Button();
            this.btnAdmins_1 = new System.Windows.Forms.Button();
            this.btnClientes_2 = new System.Windows.Forms.Button();
            this.bntVentas_3 = new System.Windows.Forms.Button();
            this.btnOrdenCompra_6 = new System.Windows.Forms.Button();
            this.btnProveedores_4 = new System.Windows.Forms.Button();
            this.btnProductos_5 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_barraTitulo = new System.Windows.Forms.Panel();
            this.picture_ocultar = new System.Windows.Forms.PictureBox();
            this.picture_minimizar = new System.Windows.Forms.PictureBox();
            this.picture_maximizar = new System.Windows.Forms.PictureBox();
            this.picture_cerrar = new System.Windows.Forms.PictureBox();
            this.panel_Contenedor = new System.Windows.Forms.Panel();
            this.panel_menuVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel_barraTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_ocultar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_minimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_maximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_cerrar)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_menuVertical
            // 
            this.panel_menuVertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.panel_menuVertical.Controls.Add(this.btn0Menú);
            this.panel_menuVertical.Controls.Add(this.btnAdmins_1);
            this.panel_menuVertical.Controls.Add(this.btnClientes_2);
            this.panel_menuVertical.Controls.Add(this.bntVentas_3);
            this.panel_menuVertical.Controls.Add(this.btnOrdenCompra_6);
            this.panel_menuVertical.Controls.Add(this.btnProveedores_4);
            this.panel_menuVertical.Controls.Add(this.btnProductos_5);
            this.panel_menuVertical.Controls.Add(this.pictureBox2);
            this.panel_menuVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_menuVertical.Location = new System.Drawing.Point(0, 0);
            this.panel_menuVertical.Name = "panel_menuVertical";
            this.panel_menuVertical.Size = new System.Drawing.Size(250, 640);
            this.panel_menuVertical.TabIndex = 0;
            // 
            // btn0Menú
            // 
            this.btn0Menú.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btn0Menú.FlatAppearance.BorderSize = 0;
            this.btn0Menú.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btn0Menú.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn0Menú.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.btn0Menú.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn0Menú.Image = ((System.Drawing.Image)(resources.GetObject("btn0Menú.Image")));
            this.btn0Menú.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn0Menú.Location = new System.Drawing.Point(0, 133);
            this.btn0Menú.Margin = new System.Windows.Forms.Padding(2);
            this.btn0Menú.Name = "btn0Menú";
            this.btn0Menú.Size = new System.Drawing.Size(250, 40);
            this.btn0Menú.TabIndex = 61;
            this.btn0Menú.Text = "Menú";
            this.btn0Menú.UseVisualStyleBackColor = false;
            this.btn0Menú.Click += new System.EventHandler(this.btn0Menú_Click);
            // 
            // btnAdmins_1
            // 
            this.btnAdmins_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnAdmins_1.FlatAppearance.BorderSize = 0;
            this.btnAdmins_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnAdmins_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmins_1.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.btnAdmins_1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAdmins_1.Image = ((System.Drawing.Image)(resources.GetObject("btnAdmins_1.Image")));
            this.btnAdmins_1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdmins_1.Location = new System.Drawing.Point(0, 178);
            this.btnAdmins_1.Name = "btnAdmins_1";
            this.btnAdmins_1.Size = new System.Drawing.Size(250, 40);
            this.btnAdmins_1.TabIndex = 54;
            this.btnAdmins_1.Text = "Administradores";
            this.btnAdmins_1.UseVisualStyleBackColor = false;
            this.btnAdmins_1.Click += new System.EventHandler(this.btnAdmins_1_Click);
            // 
            // btnClientes_2
            // 
            this.btnClientes_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnClientes_2.FlatAppearance.BorderSize = 0;
            this.btnClientes_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnClientes_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClientes_2.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.btnClientes_2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClientes_2.Image = ((System.Drawing.Image)(resources.GetObject("btnClientes_2.Image")));
            this.btnClientes_2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClientes_2.Location = new System.Drawing.Point(0, 222);
            this.btnClientes_2.Name = "btnClientes_2";
            this.btnClientes_2.Size = new System.Drawing.Size(250, 40);
            this.btnClientes_2.TabIndex = 55;
            this.btnClientes_2.Text = "Clientes";
            this.btnClientes_2.UseVisualStyleBackColor = false;
            this.btnClientes_2.Click += new System.EventHandler(this.btnClientes_2_Click);
            // 
            // bntVentas_3
            // 
            this.bntVentas_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.bntVentas_3.FlatAppearance.BorderSize = 0;
            this.bntVentas_3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.bntVentas_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bntVentas_3.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.bntVentas_3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.bntVentas_3.Image = ((System.Drawing.Image)(resources.GetObject("bntVentas_3.Image")));
            this.bntVentas_3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bntVentas_3.Location = new System.Drawing.Point(0, 266);
            this.bntVentas_3.Name = "bntVentas_3";
            this.bntVentas_3.Size = new System.Drawing.Size(250, 40);
            this.bntVentas_3.TabIndex = 56;
            this.bntVentas_3.Text = "Ventas";
            this.bntVentas_3.UseVisualStyleBackColor = false;
            this.bntVentas_3.Click += new System.EventHandler(this.bntVentas_3_Click);
            // 
            // btnOrdenCompra_6
            // 
            this.btnOrdenCompra_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnOrdenCompra_6.FlatAppearance.BorderSize = 0;
            this.btnOrdenCompra_6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnOrdenCompra_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrdenCompra_6.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.btnOrdenCompra_6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnOrdenCompra_6.Image = ((System.Drawing.Image)(resources.GetObject("btnOrdenCompra_6.Image")));
            this.btnOrdenCompra_6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOrdenCompra_6.Location = new System.Drawing.Point(0, 403);
            this.btnOrdenCompra_6.Margin = new System.Windows.Forms.Padding(2);
            this.btnOrdenCompra_6.Name = "btnOrdenCompra_6";
            this.btnOrdenCompra_6.Size = new System.Drawing.Size(250, 40);
            this.btnOrdenCompra_6.TabIndex = 59;
            this.btnOrdenCompra_6.Text = "Orden de Compra";
            this.btnOrdenCompra_6.UseVisualStyleBackColor = false;
            this.btnOrdenCompra_6.Click += new System.EventHandler(this.btnOrdenCompra_Click);
            // 
            // btnProveedores_4
            // 
            this.btnProveedores_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnProveedores_4.FlatAppearance.BorderSize = 0;
            this.btnProveedores_4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnProveedores_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProveedores_4.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.btnProveedores_4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnProveedores_4.Image = ((System.Drawing.Image)(resources.GetObject("btnProveedores_4.Image")));
            this.btnProveedores_4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProveedores_4.Location = new System.Drawing.Point(0, 312);
            this.btnProveedores_4.Name = "btnProveedores_4";
            this.btnProveedores_4.Size = new System.Drawing.Size(250, 40);
            this.btnProveedores_4.TabIndex = 57;
            this.btnProveedores_4.Text = "Proveedores";
            this.btnProveedores_4.UseVisualStyleBackColor = false;
            this.btnProveedores_4.Click += new System.EventHandler(this.btnProveedores_4_Click);
            // 
            // btnProductos_5
            // 
            this.btnProductos_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.btnProductos_5.FlatAppearance.BorderSize = 0;
            this.btnProductos_5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.btnProductos_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductos_5.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Italic);
            this.btnProductos_5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnProductos_5.Image = ((System.Drawing.Image)(resources.GetObject("btnProductos_5.Image")));
            this.btnProductos_5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductos_5.Location = new System.Drawing.Point(0, 358);
            this.btnProductos_5.Name = "btnProductos_5";
            this.btnProductos_5.Size = new System.Drawing.Size(250, 40);
            this.btnProductos_5.TabIndex = 58;
            this.btnProductos_5.Text = "Productos";
            this.btnProductos_5.UseVisualStyleBackColor = false;
            this.btnProductos_5.Click += new System.EventHandler(this.btnProductos_5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(4, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(240, 77);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel_barraTitulo
            // 
            this.panel_barraTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(1)))), ((int)(((byte)(36)))));
            this.panel_barraTitulo.Controls.Add(this.picture_ocultar);
            this.panel_barraTitulo.Controls.Add(this.picture_minimizar);
            this.panel_barraTitulo.Controls.Add(this.picture_maximizar);
            this.panel_barraTitulo.Controls.Add(this.picture_cerrar);
            this.panel_barraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_barraTitulo.Location = new System.Drawing.Point(250, 0);
            this.panel_barraTitulo.Name = "panel_barraTitulo";
            this.panel_barraTitulo.Size = new System.Drawing.Size(790, 50);
            this.panel_barraTitulo.TabIndex = 1;
            this.panel_barraTitulo.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_barraTitulo_Paint);
            this.panel_barraTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_barraTitulo_MouseDown);
            // 
            // picture_ocultar
            // 
            this.picture_ocultar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picture_ocultar.BackColor = System.Drawing.Color.Gray;
            this.picture_ocultar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picture_ocultar.Image = ((System.Drawing.Image)(resources.GetObject("picture_ocultar.Image")));
            this.picture_ocultar.Location = new System.Drawing.Point(670, 7);
            this.picture_ocultar.Name = "picture_ocultar";
            this.picture_ocultar.Size = new System.Drawing.Size(35, 31);
            this.picture_ocultar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture_ocultar.TabIndex = 4;
            this.picture_ocultar.TabStop = false;
            this.picture_ocultar.Click += new System.EventHandler(this.picture_ocultar_Click);
            // 
            // picture_minimizar
            // 
            this.picture_minimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picture_minimizar.BackColor = System.Drawing.Color.Gray;
            this.picture_minimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picture_minimizar.Image = ((System.Drawing.Image)(resources.GetObject("picture_minimizar.Image")));
            this.picture_minimizar.Location = new System.Drawing.Point(711, 7);
            this.picture_minimizar.Name = "picture_minimizar";
            this.picture_minimizar.Size = new System.Drawing.Size(35, 31);
            this.picture_minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture_minimizar.TabIndex = 3;
            this.picture_minimizar.TabStop = false;
            this.picture_minimizar.Click += new System.EventHandler(this.picture_minimizar_Click);
            // 
            // picture_maximizar
            // 
            this.picture_maximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picture_maximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picture_maximizar.Image = ((System.Drawing.Image)(resources.GetObject("picture_maximizar.Image")));
            this.picture_maximizar.Location = new System.Drawing.Point(711, 7);
            this.picture_maximizar.Name = "picture_maximizar";
            this.picture_maximizar.Size = new System.Drawing.Size(35, 31);
            this.picture_maximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture_maximizar.TabIndex = 2;
            this.picture_maximizar.TabStop = false;
            this.picture_maximizar.Click += new System.EventHandler(this.picture_maximizar_Click);
            // 
            // picture_cerrar
            // 
            this.picture_cerrar.BackColor = System.Drawing.Color.Red;
            this.picture_cerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picture_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("picture_cerrar.Image")));
            this.picture_cerrar.Location = new System.Drawing.Point(752, 7);
            this.picture_cerrar.Name = "picture_cerrar";
            this.picture_cerrar.Size = new System.Drawing.Size(35, 31);
            this.picture_cerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture_cerrar.TabIndex = 1;
            this.picture_cerrar.TabStop = false;
            this.picture_cerrar.Click += new System.EventHandler(this.picture_cerrar_Click);
            // 
            // panel_Contenedor
            // 
            this.panel_Contenedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(93)))), ((int)(((byte)(90)))));
            this.panel_Contenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Contenedor.Location = new System.Drawing.Point(250, 50);
            this.panel_Contenedor.Name = "panel_Contenedor";
            this.panel_Contenedor.Size = new System.Drawing.Size(790, 590);
            this.panel_Contenedor.TabIndex = 2;
            // 
            // frmContenedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.panel_Contenedor);
            this.Controls.Add(this.panel_barraTitulo);
            this.Controls.Add(this.panel_menuVertical);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmContenedor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel_menuVertical.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel_barraTitulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picture_ocultar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_minimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_maximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picture_cerrar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_menuVertical;
        private System.Windows.Forms.Panel panel_barraTitulo;
        private System.Windows.Forms.Panel panel_Contenedor;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox picture_cerrar;
        private System.Windows.Forms.PictureBox picture_ocultar;
        private System.Windows.Forms.PictureBox picture_minimizar;
        private System.Windows.Forms.PictureBox picture_maximizar;
        private System.Windows.Forms.Button btnAdmins_1;
        private System.Windows.Forms.Button btnClientes_2;
        private System.Windows.Forms.Button bntVentas_3;
        private System.Windows.Forms.Button btnOrdenCompra_6;
        private System.Windows.Forms.Button btnProveedores_4;
        private System.Windows.Forms.Button btnProductos_5;
        private System.Windows.Forms.Button btn0Menú;
    }
}

